package mymain;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class _02_SetTest2 {

	public static void main(String[] args) {
		
		//★Generic : 객체생성시 저장타입을 지정★
		
		
		//String Type만 저장관리
		Set<String> fruitSet  = new HashSet<String>();
		
		//Integer Type만 저장관리한다
		Set<Integer> lottoSet = new TreeSet<Integer>();
		
		fruitSet.add("사과");
		fruitSet.add("딸기");
		fruitSet.add("참외");
		fruitSet.add("수박");
		System.out.println(fruitSet);
		//나오는순서가 의미가 없는게 set은 걍주머니에 넣고 암거나 꺼내는순임
	
	
		Random random = new Random();
		
		int n =6;
		while(n>0) { // n = 6 5 4 3 2 1 
			
			int number = random.nextInt(45)+1; //1~45
			
			//중복허용되지 않는다는 속성을 이용
			if(lottoSet.add(number)==false)continue;//중복수가나오면 컨티뉴해서다시처음으로가라
			
			
			n--;
			
		}
		
		//TreeSet 자동오름차순해서 나오게 설정되어있음
		//HashSet 무작위로나옴
		System.out.println(lottoSet);
		
		//set값 빼내기 개선loop이용한 요소 추출
		System.out.println("---[개선 loop]---");
		
		// for(변수 : 배열 또는 컬렉션 또는 Map)
		for(Integer number : lottoSet) {
			System.out.printf("%3d",number);
		}
		
		
		System.out.println();//줄바꾸기
		
		
		//Iterator(반복작업)를 이용한 요소 추출 요소관리자
		System.out.println("---[Iterator 이용]---");

		
		Iterator<Integer> it = lottoSet.iterator();
		while(it.hasNext()) {// hasNext=요소를 가지고 있냐?
			
			int number = it.next(); //next = 가져온후 다음으로 이동
			System.out.printf("%3d",number);
			
		}
		
		
	}

}
