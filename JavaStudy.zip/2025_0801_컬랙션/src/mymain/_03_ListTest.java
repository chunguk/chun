package mymain;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class _03_ListTest {

	public static void main(String[] args) {
		
		//ArrayList : 동적배열
		//			: 순서가 있는 자료구조
		//			: 중복허용된다
		//	interface		   =  	new 클래스()
		//  설명서					설계서
		List<String> sido_list = new ArrayList<String>();
		
		System.out.println(sido_list.size());
		
		sido_list.add("서울");//0
		sido_list.add("대전");//1
		sido_list.add("대구");//2
		sido_list.add("울진");//3
		sido_list.add("부산");//4
		sido_list.add("제주");//5
		
		System.out.println(sido_list.size());
		
		//set == 배열하나만떼서 경기도로 수정
		sido_list.set(1, "경기도");
		
		System.out.println(sido_list);
		
//		System.out.println(sido_list.get(4-1));//인덱스값자리뽑기
		System.out.println("---[첨자를 이용한 요소 추출]---");
		for(int i=0; i<sido_list.size();i++) {
			System.out.printf("sido_list's %d번째 요소 : %s\n",i+1,sido_list.get(i));
		}
		System.out.println();
		sido_list.remove("대구");
		
//		System.out.println(sido_list.get(4-1));//인덱스값자리뽑기
		System.out.println("---[첨자를 이용한 요소 추출(remove로 대구 삭제한후)]---");
		for(int i=0; i<sido_list.size();i++) {
			System.out.printf("sido_list's %d번째 요소 : %s\n",i+1,sido_list.get(i));
		}
		
		
		System.out.println();	//줄바꾸기
		
		System.out.println("개선 loop [String sido : sido_list]");
		
		for(String sido : sido_list) {
			System.out.printf("%4s",sido);
		}
		
		System.out.println();	//줄바꾸기
		
		System.out.println("-----[Iterator[반복기]를 이용]-----");

		Iterator<String> it = sido_list.iterator();
		
		while(it.hasNext()) {
		
		String sido = it.next();
		
		System.out.printf("%5s",sido);
		
		
		}
	}
}
