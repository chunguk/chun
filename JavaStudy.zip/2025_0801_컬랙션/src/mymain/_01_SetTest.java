package mymain;

import java.util.HashSet;
import java.util.Set;

public class _01_SetTest {

	public static void main(String[] args) {
		//Collection
		//1. 자바의 객체(Object)만 저장관리하는 자료구조
		
		
		//Set
		// ㄴHashSet	or	TreeSet
		//1. 순서없이 저장관리 되는 자료구조
		//2. 중복허용되지 않는다

			//인터페이스 = new 클래스();
			//	인터페이스->설명서  /  클래스->설계서
			Set 	set    =    new HashSet();
		
			
			//Integer iOb = new Integer(20); 밑에랑 같음
			Integer iOb = Integer.valueOf(20);
			
			set.add(iOb);
			
			
			//Auto-Boxing JDK 5.0이후부터 지원되는 기능
			Integer iOb1 = 1; // 1 -> new Integer(1)
			
			//Auto-UnBoxing
			int		n = iOb1;// intValue();
			double	d = iOb1;// doubleValue();
			float	f = iOb1;// floatValue();
			
			set.add(1); // Integer.valueOf(1) 이렇게 객체로 만들어서 들어감
			set.add(20);
			set.add(25);
			set.add(5);
			set.add("아무거나");
			set.add(10.5);	//Double.valueOf(10.5) == new Double(10.5)
			set.add(true);	//Boolean.valueOf(true)
			
			
			Double.valueOf(10.5);
			Boolean.valueOf(true);
			
			//중복값은 허용되지않아서 5개만나옴
			System.out.println(set);
			
	}

}
