package mymain;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class _07_문제1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n;
		List<Integer>n_list = new ArrayList<Integer>();
		
		System.out.println("갯수를 입력하세요");
		n = scanner.nextInt(); //입력받은갯수값을 n변수에 넣음
		
		System.out.println("값:");
		for(int i=0; i<n; i++) {
			
			int m = scanner.nextInt();
			n_list.add(m);
		}
		System.out.println(" 리스트 : " + n_list);

//		 n = scanner.nextInt();
		 
		
//		n_list.add(n); //n_list에 n값을 차례대로 넣음
		
		//15342
		//1. 첫번째수는 버린다  remove  	답 : 5342
		//2. 다음수는 마지막으로 보낸다 	답 : 3425
		//3. 1개가 남을때까지 반복한다		

	//12345 -> 2345 ->  3452  -> 452  -> 524  -> 24 -> 42 -> 2만남네
		
		while(n_list.size()>1) { //숫자 1개남을때까지 반복
			//1.1번째 수 지우기
			n_list.remove(0); 
			
			
			if(n_list.size()>1) {//숫자1개남을떄까지 반복
				int move = n_list.remove(0);  //변수move에 인덱스0번을 넣는데
				n_list.add(move); //그리고 move에 들어있는값을 다시add해서 넣는다 맨뒤로
			}
		}
		System.out.println(n_list.get(0)); //남아있는 한자리를 불러온다
	

		
		scanner.close();
	
	}//main

}
