package mymain;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class _06_MapTest2 {

	public static void main(String[] args) {
		
		// 단어장 용도의 맵
		// key=word value = "뜻"
		// key=one	value = "하나란 뜻입니다.
		
		//notemap이라는 객체 생성
		Map<String, String> notemap = new TreeMap<String, String>();
		
		notemap.put("1.Interface(설명서)","설명 : \"이렇게 동작해야 해!\" 라는 **규칙(약속)**만 정의해놓는 **틀(설계도)**입니다.\n");
		notemap.put("2. Class(설계서)", "설명 : *클래스는 설계도(청사진, 설계서)**입니다.\n");
		
		notemap.put("3. Iterator (반복자)", "설명 :컬렉션(List, Set 등)에 저장된 데이터를 하나씩 꺼내면서 반복 처리할 수 있게 해주는 **도구(객체)**입니다.\r\n");
		
				 notemap.put("4. Set", "설명 : 	1. 순서없이 저장관리 되는 자료구조\r\n"
				+ "	2. 중복허용되지 않는다");
		
		
		System.out.println(notemap);
		
		
		System.out.println("----------------------------------------[keySet]----------------------------------------");
		//Keyset 앞에 단축키만 뽑기
		Set<String> keyStrings = notemap.keySet();
		
		System.out.println(keyStrings);
		
		for(String key : keyStrings) {
			System.out.println(key);
		}
		
	}//main

}
