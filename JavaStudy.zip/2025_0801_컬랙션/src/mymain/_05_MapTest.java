package mymain;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class _05_MapTest {

	public static void main(String[] args) {
		
		//Map : Key , Value 한쌍으로 저장관리되는 자료구조
		
		//TreeMap = 자동정렬  HashMap = 랜덤정렬
		Map<Integer, String> telmap = new TreeMap<Integer, String>();
		
		telmap.put(Integer.valueOf(1), "010-2611-4610");
		telmap.put(2, "010-2611-4611"); //key:Auto-Boxing되어서 들어간다
		telmap.put(3, "010-2611-4612");
		telmap.put(4, "010-2611-4613");
		telmap.put(5, "010-2611-4614");
		
//		telmap.put(1, "010-0000-0000");//같은 키값주면 덮어씌워버림
	
	
		System.out.println(telmap);
	
		int shor_num = 2;	//인덱스넘버 2
		String result_tel = telmap.get(shor_num); //텔맵에 단축넘버값을 리절트에넣음
		
		System.out.printf("단축번호 %d번 = %s\n",shor_num,result_tel);
	
	
		//전체정보를 조회
		//Map으로부터 Key의 집함(Set)을 얻어온다
		Set<Integer> keySet = telmap.keySet();
		
		System.out.println(keySet);
		
		System.out.println("-----[맵전체정보]-----");
		for(Integer key : keySet) {
			String value = telmap.get(key);
			
			System.out.printf("단축번호 [%d] = [%s]\n",key,value);
			
			
		}//main
	}

}
