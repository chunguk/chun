package Myutil;

public class MyArrays2 { //2차 함 배열 유틸
								
	public static void display(int [][] ar2) {
		
		for(int row=0; row < ar2.length; row++) {
			
			for(int col=0; col < ar2[row].length; col++) {
				
				System.out.printf("%3d",ar2[row][col]);
			}
			System.out.println(); //줄바꿈 
			
		}//end for
		
	}//display
	
	public static void display_block(int [][] ar2) {
		
		for(int row=0; row < ar2.length; row++) {
			
			for(int col=0; col < ar2[row].length; col++) { //해당 행(row)에 있는 열의 개수 (각 줄의 칸 수)
				
				if(ar2[row][col]==1) {
					System.out.print("■");
				}else {
					System.out.print("　");
				}
				
			}
			System.out.println(); //줄바꿈
			
		}//end for
		
	}//display
	
	
	
	//순서대로 배열에 값을 채우는 메소드
	
	public static void set(int [][] ar2) {
		
		int num=1;
		
		for(int row=0; row < ar2.length; row++) {
			
			for(int col=0; col < ar2[row].length; col++) {
				
				ar2[row][col]= num++; //값을넣고 num증가
//				num++;
			}
		
		}//end for
		
	}//end set
	
	
	
	
	
	
	
}
