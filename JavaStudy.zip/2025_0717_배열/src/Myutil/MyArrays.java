package Myutil;

public class MyArrays {

	// 지역변수 로컬 변수 ar은 여기 안에서만 쓰인다

	public static void display(int[] ar) {

		System.out.print("[");
		for (int i = 0; i < ar.length; i++) {
			System.out.printf("%2d", ar[i]);
		}
		System.out.println(" ]");// 줄바꾸기

	}

	public static void fill(int[] ar, int value) {

		for (int i = 0; i < ar.length; i++)
			ar[i] = value;
		/*
		 * ar[0] = value; ar[1] = value; ar[2] = value; ar[3] = value;
		 */

	}

	// 오름차순거품정렬(Bubble Sort)
	public static void Bubble_Sort_sort_asc(int[] mr) {

		for (int i = 0; i < mr.length - 1; i++) {

			for (int k = 0; k < mr.length - i - 1; k++) {
				if (mr[k] > mr[k + 1]) {
					int tmp = 0;

					tmp = mr[k];
					mr[k] = mr[k + 1];
					mr[k + 1] = tmp;

				}
			}
		}
	}

	public static void Bubble_Sort_sort_desc(int[] mr) {

		for (int i = 0; i < mr.length - 1; i++) {

			for (int k = 0; k < mr.length - i - 1; k++) {
				if (mr[k] < mr[k + 1]) {
					int tmp = 0;

					tmp = mr[k];
					mr[k] = mr[k + 1];
					mr[k + 1] = tmp;

				}
			}
		}
	}

	// 오름차순정렬
	public static void sort_acs(int[] mr) {
		for (int i = 0; i < mr.length; i++) {

			for (int k = i + 1; k < mr.length; k++) {

				if (mr[i] > mr[k]) {
					int im = mr[i];
					mr[i] = mr[k];
					mr[k] = im;
				}
			}
		} // end for
	}

	// 내림차순정렬
	public static void sort_desc(int[] mr) {
		for (int i = 0; i < mr.length; i++) {

			for (int k = i + 1; k < mr.length; k++) {

				if (mr[i] < mr[k]) {
					int im = mr[i];
					mr[i] = mr[k];
					mr[k] = im;
				}
			}
		} // end for
	}

	// 오름차순정렬
	public static void sort_acs(int[] mr, int beginIndex, int toIndex) {
		for (int i = beginIndex; i < toIndex - 1; i++) {

			for (int k = i + 1; k < toIndex; k++) {

				if (mr[i] > mr[k]) {
					int im = mr[i];
					mr[i] = mr[k];
					mr[k] = im;
				}
			}
		} // end for
	}

	// 내림차순
	public static void sort_desc(int[] mr, int beginIndex, int toIndex) {
		for (int i = beginIndex; i < toIndex - 1; i++) {

			for (int k = i + 1; k < toIndex; k++) {

				if (mr[i] < mr[k]) {
					int im = mr[i];
					mr[i] = mr[k];
					mr[k] = im;
				}
			}
		} // end for
	}

}// class
