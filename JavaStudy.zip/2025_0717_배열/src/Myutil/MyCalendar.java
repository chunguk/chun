package Myutil;

import java.util.Calendar;

public class MyCalendar {	//객체 MyCalendar
	
	int [] month_array = {31,28,31,30,31,30,31,31,30,31,30,31}; //월 배열
	int [][]cal_array =null;

	int year;		//연도값받기윕한변수
	int month;		//월값받기위한변수
	
	public void setDate(int year, int month) {
		this.year = year;
		this.month = month;
		
		
		make_calendar();
		
	}	

	//윤년여부
	boolean isYoon() {//year가 400으로 나눳더니 0이면 윤년이지
		return (year %400 ==0 || (year %4 ==0 && year %100!=0)); 
	}
	
	int getTotalDays() {
		//윤년체크
		if(isYoon())
			month_array[1] = 29;
		else month_array[1] = 28;
		
		//총날수 : 1년1월1일을 기준으로
		int total_days =0;
		
		total_days = (year-1) * 365;
		
		//윤년의 따르 일수 추가
		total_days = total_days + (year/400 + year/4 - year/100);
		//									4의배수에서 100의배수를 뺸다
		//월수누적 (전달까지)
		for(int i=0; i<month-1; i++) {//month-1 -1로 인해 전달이됨 
			total_days = total_days + month_array[i];
		}
		
		//1일추가
		total_days++;
		
		return total_days;
	}
	

	
	
	private void make_calendar() {
		cal_array = new int[6][7];
		
		int week = 0; //행첨자(주차)
		int yoil =0;  //열첨자(요일)
		//윤년체크
		if(isYoon()) {
			month_array[1]=29;
		}else 
			month_array[1]=28;
		
		//지정된날자의요일으구한다
		Calendar my_date = Calendar.getInstance();
		
		my_date.set(year, month-1,1 );//month 0=1월 1=2월
		
		yoil = my_date.get(Calendar.DAY_OF_WEEK)-1;// calendar에서도  1:sun 2:mon
		
		yoil =getTotalDays()%7;
		System.out.println(yoil);
		
		
		//월의 마지막날
		int last_day = month_array[month-1];
		//이전달의 마지막날
		int last_day2 = month_array[month-1];

		
		
		//2.이전달 채우기
		 for (int i = yoil - 1; i >= 0; i--) {
		        cal_array[0][i] = last_day2--;  
	}//for i
		
		
		
		
		
		for(int i=1; i<=last_day;i++) {// 1 2 3 ...마지막날까지돔
		
				cal_array[week][yoil]=i;
				
				//다음칸이동
				yoil++;
				
				if(yoil >6) {	//다음줄로이동
					week++;		
					yoil=0; //첫번째칸으로이동
				}
		}//for i
		
		
		//3.다음달 날짜 채우기
		for(int i=1; i<=last_day;i++) {// 1 2 3 ...마지막날까지돔
			
			cal_array[week][yoil]=i;
			
			//다음칸이동
			yoil++;
			
			if(yoil >6) {	//다음줄로이동
				week++;		
				if(week>5) break;
				yoil=0; //첫번째칸으로이동
			}
	}//for i
		
		
		//위크가 5보다크면 break 다출력했다는뜻
		
	}//make_calendar
	
	public void display() {
		//1.요일타이틀 출력
		String [] day = {"일","월","화","수","목","금","토"};
				for(int i=0; i<day.length;i++) {
					System.out.printf("%3s",day[i]);
				}
		System.out.println();
		
		for(int i=0; i<6; i++) {		//행[주차]
			
			for(int k=0; k<7; k++) {	//열(요일)
				System.out.printf("%4d",cal_array[i][k]);
			}//for - k
			
			System.out.println();//for 문끝나면 줄바꾸기
			
		}//for - i
		
	}
	
}//class
