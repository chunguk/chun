package Myutil;

public class MaBangJin {

	public static int [][] make(int chasu){//차수를 넘겨 받는 make함수
		
		int[][] ma_array = new int [chasu][chasu];
		
		//1.중앙부터 채운다
		
		int row = 0; //첫번째 행
		
		int col= chasu/2; //차수/2를하면 중앙이된다
		
		int num = 1;
		
		ma_array [row][col] = num++;
		
		//2. 마방진채우기
		for(int i=0; i<chasu*chasu-1; i++ ) {
			
			//대각으로 이동
			row--; //행을위로
			col++; //열을 오른쪽으로
			
			//위와 오른쪽으로 모두 벗어낫냐?
			if(row < 0 && col ==chasu) {
				row = row+2;
				col = col-1;
			}else if(row<0) {
				//위쪽으로 벗어났냐?=> 마지막줄로이동시킨다
				row = chasu-1; //맨밑으로가라
			}else if(col==chasu) {
				//우측으로 벗어났냐? => 맨앞칸으로 이동시킨다
				col = 0;
			}
			
			//값이 이미 채워져있으면
			if(ma_array[row][col]!=0) {
					row = row+2;
					col = col-1;
			}
			//답채우기
			
			ma_array [row][col]=num++;
			
			
		}//end for
		
		
		
		
		
		return ma_array;
	}
	
}//class









//