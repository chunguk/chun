package Myutil;

import java.util.Random;

public class BaseBall {

	int[] com_no = new int[3];
	
	 Random random = new Random();
	 
	 public void make_no() {
		 
		 OUT_FOR:
			 for(int i=0; i<com_no.length; i++) {
				 
				 int su = random.nextInt(9)+1; // 1~9
				 
				 //중복수 체크
				 for(int k=0; k<i; k++) {
					 
					 //같은수가 있으면
					 if(su==com_no[k]) { //su가 k넘버랑 같냐
						 i--;
						 continue OUT_FOR;
					 }
				 }//k
				 
				 com_no[i]= su;
				 
			 }//i
	 }
	 

	 
	 public static boolean isValid(int[] user_no) {
		    for (int i = 0; i < user_no.length; i++) {
		        // 1~9 사이 숫자인지 확인
		        if (user_no[i] < 1 || user_no[i] > 9) return false;

		        // 중복 확인
		        for (int j = i + 1; j < user_no.length; j++) {
		            if (user_no[i] == user_no[j]) return false;
		        }
		    }
		    return true;
		}
	 
	 
	 public int[] check(int[] user_no) {
		 //스트라이크 볼 아웃 정보 반환
		 int strike = 0;
		 int ball =0;
				 
		 for(int i=0; i < com_no.length; i++) {
			 for(int j=0; j<user_no.length; j++) {
				 if(com_no[i]==user_no[j]) {
					 if(i==j) {
						 strike++;
					 }else ball++;
				 }
			 }
		 }
				 
				 return new int[] {strike,ball};
	 }
	 
	 
	 
	 
	 



	
	
}
