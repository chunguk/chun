package Myutil;

public class MyTrans {

	public static int [][] up_donw(int [][] src){
		
		//복사본 배열
		int rows =src.length; //원본의 행의갯수
		int cols = src[0].length; //열의 갯수
		
		int [][] dest = new int[rows][cols]; //
		
		//원본배열의 값을 조건에 맞게끔 옮기는 작업
		for(int i=0; i<rows; i++) {
			for(int k=0; k< cols; k++) {
				
				dest[i][k]= src[(rows-1)-i][k]; //rows-1 -1은 첨자는  0부터 시작해서 -1함
				
			}
		}
			
		return dest;
		
		
	}
	
	public static int [][] diagonal2(int [][] src){
		
		//복사본 배열
		int rows =src.length; //원본의 행의갯수
		int cols = src[0].length; //열의 갯수
		
		int [][] dest =new int[rows][cols]; //
		
		//원본배열의 값을 조건에 맞게끔 옮기는 작업
		for(int i=0; i<rows; i++) {
			for(int k=0; k< cols; k++) {
				
				dest[i][k]= src[k][(cols-1)-i]; //rows-1 -1은 첨자는  0부터 시작해서 -1함
				
			}
		}
		
		return dest;
	}//diagonal
	
	public static int [][] diagonal(int [][] src){
		
		//복사본 배열
		int rows =src.length; //원본의 행의갯수
		int cols = src[0].length; //열의 갯수
		
		int [][] dest =new int[rows][cols]; //
		
		//원본배열의 값을 조건에 맞게끔 옮기는 작업
		for(int i=0; i<rows; i++) {
			for(int k=0; k< cols; k++) {
				
				dest[i][k]= src[(rows-1)-k][(cols-1)-i]; //rows-1 -1은 첨자는  0부터 시작해서 -1함
				
			}
		}
		
		return dest;
	}//diagonal
	public static int [][] diagonal3(int [][] src){
		
		//복사본 배열
		int rows =src.length; //원본의 행의갯수
		int cols = src[0].length; //열의 갯수
		
		int [][] dest =new int[rows][cols]; //
		
		//원본배열의 값을 조건에 맞게끔 옮기는 작업
		for(int i=0; i<rows; i++) {
			for(int k=0; k< cols; k++) {
				
				dest[i][k]= src[(rows-1)-i][(cols-1)-k]; //rows-1 -1은 첨자는  0부터 시작해서 -1함
				
			}
		}
		
		return dest;
	}//diagonal
		
	
		
	
	public static int [][] rotate_right_90(int [][] src){
		
		//복사본 배열
		int rows =src.length; //원본의 행의갯수
		int cols = src[0].length; //열의 갯수
		
		int [][] dest =new int[rows][cols]; //
		
		//원본배열의 값을 조건에 맞게끔 옮기는 작업
		for(int i=0; i<rows; i++) {
			for(int k=0; k< cols; k++) {
				
				dest[i][k]= src[(rows-1)-k][i]; //rows-1 -1은 첨자는  0부터 시작해서 -1함
				
			}
		}
		
		return dest;
	}//up_donw
			
		public static int[][] qwer (int[][] src1){
			
		
		
			
			int rows = src1.length; // 행의길이
			int cols = src1[0].length; //열의길이
			
			int [][] ex = new int[rows][cols]; //초기화하면서 리턴을받아옴
			
			
			for(int i=0; i<rows; i++) {	//행을 rows만큼채워라
				for(int k=0; k<cols; k++) { //cols을 열만큼 채워라
					ex[i][k]= src1[i][k];
				}
			}
			return ex;
		}

	
	
	
	
	}//class


