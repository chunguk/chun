package Mymain;

import java.util.Scanner;

public class Mymain_Array1_활용 {

	public static void main(String[] args) {
		//					 1  2  3  4  5  6  7  8  9 10 11 12 < - 월
		//		 		     0  1  2  3  4  5  6  7  8  9 10 11	< - index -1
		
		int[] month_array= {31,28,31,30,31,30,31,31,30,31,30,31};
		int month;
		
		Scanner scanner = new Scanner(System.in);
	
		System.out.println("월을입력하세요");
		month = scanner.nextInt();
		if(month < 1 && month > 12) System.out.print("1~12월 사이만 입력해주세요");
		
		int lastday = month_array[month-1];
		
		System.out.printf("[%d]월에 마지막날은 [%d]일 입니다\n",month,lastday);
		
		
		
		scanner.close();

	}

}
