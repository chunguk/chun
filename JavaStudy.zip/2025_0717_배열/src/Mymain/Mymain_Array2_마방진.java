package Mymain;

import Myutil.MaBangJin;
import Myutil.MyArrays2;

public class Mymain_Array2_마방진 {

	public static void main(String[] args) {

		int chasu =5;
		
		int[][] result_magic_square= MaBangJin.make(chasu);
		
		
		MyArrays2.display(result_magic_square);
		
		
		int row_sum=0;
		int col_sum=0;
		int dia_sum=0;
		
		for(int i=0; i<chasu; i++) {
			
			//행합계
			row_sum  = row_sum + result_magic_square[0][i];
			
			//열합계
			col_sum = col_sum + result_magic_square [i][0];
			
			//대각의합계
			dia_sum = dia_sum + result_magic_square[i][i];
			
		
			
		}//end for
		System.out.println("◎◎◎◎◎result◎◎◎◎◎");
		System.out.printf("행합계 : %d\n",row_sum);
		System.out.printf("열합계 : %d\n",col_sum);
		System.out.printf("대각합계 : %d\n",dia_sum);
		
		
	}//main

}
