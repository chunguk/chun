package Mymain;

import java.util.Arrays;

import Myutil.MyArrays;

public class MyMain_Array1_초기화 {

	public static void main(String[] args) {
		
		
		int n =10; //변수 선언과 동시에 값을 넣는것:초기화
		
		int [] ar1 = new int[] {1, 2, 3, 4, 5 };	//배열 초기화 식 :int [] ar1 = new int[] {};
		
		int [] ar2 = {3, 1, 5, 2, 4};	// new int[] 생략가능
		
		
		MyArrays.display(ar1);
		
		System.out.println("---[before sort]---");

		MyArrays.display(ar2);
		
		System.out.println("---[after sort]---");
		
		//기존API 이용
//		Arrays.sort(ar2);	//sort 정렬
		
		MyArrays.sort_acs(ar2); //sort는 오름차순 12345
		MyArrays.display(ar2); 	//디스플레이는 보기용
		
		
		System.out.println("---[after desc() sort]---");
		MyArrays.sort_desc(ar2); //sort desc 내림차순정렬  54321
		MyArrays.display(ar2);	//디스플레이는 보기
		
		
		System.out.println("---[after desc(1~3) sort]---");
		Arrays.sort(ar2, 1, 4);	 //1번째부터 3개 소팅해라 4번째는 포함안되서 3개만됨
//		MyArrays.sort_acs(ar2,1,4); //sort desc 내림차순정렬  54321
		MyArrays.display(ar2);

		
		System.out.println("---[ acs(1~3) sort]---");
		
		MyArrays.sort_acs(ar2,1,4); //sort desc 내림차순정렬  54321
		MyArrays.display(ar2);
		
		System.out.println("---[ desc(1~3) sort]---");
		
		MyArrays.sort_desc(ar2,1,4); //sort desc 내림차순정렬  54321
		MyArrays.display(ar2);
		
		System.out.println("---[Bubble Sort]---");

		MyArrays.Bubble_Sort_sort_asc(ar2);
		MyArrays.display(ar2);
		
		System.out.println("---[Bubble Sort_desc]---");
		
		MyArrays.Bubble_Sort_sort_desc(ar2);
		MyArrays.display(ar2);
		
	}//end main

}
