package Mymain;

import java.util.Scanner;

import Myutil.BaseBall;

public class MyMain_야구게임 {

	public static void main(String[] args) {
		
		Scanner scanner =new Scanner(System.in);
		int [] user_no =  new int[3];
		int out_count = 0;
		
		BaseBall baseBall = new BaseBall();
		baseBall.make_no(); 

		while(out_count<3) {
			System.out.println("숫자를 3개입력하세요 중복x");
			
			
			user_no[0] = scanner.nextInt();
			user_no[1] = scanner.nextInt();
			user_no[2] = scanner.nextInt();
			
            // 유효성 검사
            if (!BaseBall.isValid(user_no)) {
                System.out.println("잘못된 입력입니다! 1~9 숫자 중 중복 없이 3개를 입력하세요.");
                continue;
            }

			
			//유혀성체크
//			baseBall.setUser_no(user_no);
			int[] result = baseBall.check(user_no);
//			int[] result = baseBall.check(user_no);
			
			int strike = result[0];
			int ball = result[1];
			
			if (strike == 0 && ball == 0) {
				out_count++;
				System.out.println(" 아웃! (" + out_count + " OUT)");
			} else {
				System.out.println("결과: " + strike + " 스트라이크, " + ball + " 볼");
			}

			if (strike == 3) {
				System.out.println(" 정답입니다! 게임 종료!");
				break;
			}

		
			
		}//while
			
	if (out_count == 3) {
		System.out.println(" 아웃 3번으로 게임 종료!");
	}
		
		
		scanner.close();
		
		
		
	}
}	
	


