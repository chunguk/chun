package Mymain;

import Myutil.MyArrays2;

public class MyMainArray2_0 {

	public static void main(String[] args) {
		
		//					 행 열	mm은 3행4열 배열만 만들어 저장함 행을 먼저 만듦
		int [][] mm = new int[3][4];
		
		mm [0][0]=1;
		mm [0][1]=2;
		
		
		MyArrays2.set(mm);
		MyArrays2.display(mm);

		
		
		
		
		
		
	}

}
