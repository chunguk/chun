package Mymain;

import java.util.Calendar;
import java.util.Scanner;

public class Mymain_Array1_활용2 {

	public static void main(String[] args) {

		//나이 띠 60갑자 윤년 평년 구하기
		int year;
		int age;
//		Calendar now = null;
//		int current_year = now.get(Calendar.YEAR);// 상수 다 대문자
		
	
		Scanner scanner = new Scanner(System.in);
		System.out.println("출생년도");
		
		year = scanner.nextInt();
		age = 2025 - year;
		
		//			띠 인덱스 0 1 2 3 4 5 6 7 8 9 10 11 12 
		//			태어난 년도 %12해서 나머지를 0~12중 하나 추적해서 myZodiac에 삽입
		String[] zodiac = {"원숭이","닭","개","돼지","쥐","소","호랑이","토끼","용","뱀","말","양"};
		String myZodiac = zodiac[year % 12];//태어난 년도 %12해서 나머지를 0~12중 하나 추적해서 myZodiac에 삽입

		
		
		String[] 천간 = {"갑","을","병","정","무","기","경","신","임","계"};
		
		String[] hanja = {"자","축","인","묘","진","사","오","미","신","유","술","해"};
		
		String[] 오행색 = {"푸른", "푸른", "붉은", "붉은", "노란", "노란", "흰", "흰", "검은", "검은"};
		
		int gapjaIndex = (year - 1984 + 60) % 60; // 기준: 1984년 = 갑자
		
		String gan = 천간[gapjaIndex %10];
		String myHanja = hanja[gapjaIndex %12];
		String Ohang = 오행색 [gapjaIndex % 10];
		
		
		boolean yoon = (year%4==0 && year % 100 !=0) ||(year % 400==0);
		String myYoon = yoon ? "윤년" : "평년";
		
		
		System.out.printf("나이는 만[%d]입니다\n",age);
		System.out.printf("당신의 띠[%s]는\n",myZodiac);
		System.out.printf("당신의 태어난 해는[%s][%s]년입니다.\n",gan,myHanja);
		System.out.printf("당신의 태어난 해는 윤년/평년중 [%s]입니다 \n",myYoon);
		System.out.printf("당신의 태어난 오행색은 [%s][%s]입니다\n",Ohang,myHanja);
		
		//나이 = 현재년도-출생년도
		
		//현재시스템 시간구하기 : 년 월 일 시 분 초 AM PM 주 요일
//		Calendar now1 = Calendar.getInstance();
		
		//년도 구하기             지금 년도를 구함
//		int current_year = now.get(Calendar.YEAR);// 상수 다 대문자
//		
//		int current_month= now.get(Calendar.MONTH)+1;
		
		
		scanner.close();

	}

}
