package Mymain;

import Myutil.MyArrays2;

public class MyMain_Array2_초기화 {

	public static void main(String[] args) {
		//					갯수 생략
		int [][] mm= new int[][] {
									{1,2,3,4},
									{5,6,7,8,},
									{9,10,11,12}
								  };
					// 	new int[][]	생략가능	  
	  	int [][] mm2=  {
						  {1,2,3,4},
						  {5,6,7,8,},
						  {9,10,11,12}
	  					};
								  
	  MyArrays2.display(mm);
	  MyArrays2.display(mm2);
	  
	  int[][] block_t= {
						  {1,1,1},
						  {0,1,0},
						  {0,1,0},
	  					};
	  
	  int[][] block_L= {
						  {1,0,0},
						  {1,0,0},
						  {1,1,1},
	  					};
	  int[][] block_box= {
						  {1,1,1},
						  {1,0,1},
						  {1,1,1},
	  					};
	  
	  System.out.println("---T Block---");
	  MyArrays2.display_block(block_box);
	  
	  System.out.println("---L Block---");

	  MyArrays2.display_block(block_L);
	  System.out.println("---T Block---");

	  MyArrays2.display_block(block_t);
	
	  
	  
	  
	  
	  
								  
	}//main

}