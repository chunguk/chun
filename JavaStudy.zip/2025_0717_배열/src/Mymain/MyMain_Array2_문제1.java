package Mymain;

import Myutil.MyArrays2;
import Myutil.MyTrans;

public class MyMain_Array2_문제1 {

	public static void main(String[] args) {
			
		int chasu =5;
		int chasu1 =5;
		
		//원본
		int[][]src= new int [chasu][chasu];
		int[][]src1= new int [chasu1][chasu1];
		MyArrays2.set(src);	//순서대로 배열에 값을 채우는 메소드set
		MyArrays2.set(src1);

		
		System.out.println("---[scr]---");
		MyArrays2.display(src);
		System.out.println();
		
		System.out.println("---[up_donw]---");
		int[][] result =MyTrans.up_donw(src); //마이트랜스에 배열값을가져옴
		MyArrays2.display(result);
		System.out.println();
		
		
		System.out.println("---[diagonal]---");
		int[][] result4 =MyTrans.diagonal3(src); //마이트랜스에 배열값을가져옴
		MyArrays2.display(result4);
		System.out.println();
		
		System.out.println("---[diagonal2]---");
		int[][] result3 =MyTrans.diagonal2(src); //마이트랜스에 배열값을가져옴
		MyArrays2.display(result3);
		System.out.println();
		
		System.out.println("---[diagonal]---");
		int[][] result2 =MyTrans.diagonal(src); //마이트랜스에 배열값을가져옴
		MyArrays2.display(result2);
		System.out.println();
	
		System.out.println("---[up donw]---");
		int[][] result1 =MyTrans.rotate_right_90(src); //마이트랜스에 배열값을가져옴
		MyArrays2.display(result1);
		System.out.println();
//		
//		int[][]result5=MyTrans.qwer(src1);
//		MyArrays2.display(result5);
//		System.out.println();
		
		
		
		//rotate_right_90 up_donw
		
	}

}
