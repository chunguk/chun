package Mymain;

import java.util.Scanner;

import Myutil.MyArrays2;
import Myutil.Snail;

public class MyMain_달팽이 {

	public static void main(String[] args) {
		int chasu;
		String yn = "y"; //계속할거야?
		
		Scanner scanner =new Scanner(System.in);
		
		while(true) {
			
			System.out.print("차수");
			chasu = scanner.nextInt();
			
			
			//달팽이 객체 생성-> 출력
			int [][] result_snail = Snail.make(chasu);
			
			//출력
			MyArrays2.display(result_snail);
			
			
			//계속할거야?
			System.out.println("계속?(y/n):");
			yn = scanner.next();
			
			if(!yn.equalsIgnoreCase("Y"))break;
			
			
		}//End while
		
		System.out.println("---★[E-N-D]★---");
		
		scanner.close();
		
		
	}

}
