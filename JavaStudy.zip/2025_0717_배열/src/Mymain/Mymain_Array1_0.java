package Mymain;

import java.util.Arrays;

import Myutil.MyArrays;

public class Mymain_Array1_0 {

	public static void main(String[] args) {
	
		//1차원배열
		
		//stack에 선언한 변수는 초기화 안된다 초기화해야됨
		int n=0;
		
		//heap에 할당된 변수는 자동초기화 된다
		//정수형 : 0
		//실수형 : 0.0
		//boolean: false
		//참조형 : null
		int[] mr = new int[4]; //heap에 할당됨
		
		mr[0] = 1;
		mr[1] = 2;
		mr[2] = 3;
		mr[3] = 4;
		
//		
//		System.out.println(mr[2]);
//		System.out.println(n);
		
		//호출할떄 stack메모리에 할당 리턴할때 다시 회수
		MyArrays.display(mr);
		
		//fill = 채운다
		Arrays.fill(mr,77);
		
		MyArrays.display(mr);

		
	}

}
