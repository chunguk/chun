package mymain;

public class MyMain_03_String03_문자열결합 {

	public static void main(String[] args) {
		
		int count =0;
		String msg = ++count + " little," + ++count +" little," + ++count + " little Indian ";
		
		System.out.println(msg);
		System.out.println(msg.length());
//		
		System.gc();
		
		
		
		//해결방안 StringBuffer or StringBuilder 이용해라
		//버퍼는 처리속더 느리다	StringBuilder 처리속도 빠름
//		int count = 0;
		StringBuffer sb = new StringBuffer(34);
		sb.append(++count);
		sb.append(" little," );
		sb.append(++count);
		sb.append(" little," );
		sb.append(++count);
		sb.append(" little,Indian" );
		
		String msg1 = sb.toString();
		System.out.println(msg1);
		
		//해결방안2: String format(): 문자열 생성 메소드
		count= 0;
		String msg2 = String.format("%d little,%d little,%dlittle Indian",++count,++count,++count);
		System.out.println(msg2);
	}

}
