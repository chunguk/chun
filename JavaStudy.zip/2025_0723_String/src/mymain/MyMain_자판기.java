package mymain;

import java.util.Scanner;

import myutil.Vending_Machine;

public class MyMain_자판기 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int money;
		int drink;
		String yn = "y";
		
		while(true) {
			System.out.println("금액을 넣어주세요");
			money = scanner.nextInt();
			
			System.out.println("음료선택(1.콜라 2.사이다 3.쥬스 4.우유)");
			drink = scanner.nextInt();
			
			Vending_Machine vending_Machine = new Vending_Machine();
			
			//자판기에게 금액과 선택음료정보 전달
			vending_Machine.insertCoin(money);
			vending_Machine.selectDrink(drink);
	
			
//			Vending_Machine vending_Machine2 = new Vending_Machine();
			//결과 출력
			vending_Machine.displayResult1();
			
			
			
			//계속할거야?
			System.out.println("계속 주문 하시겠습니까?");
			yn = scanner.next();
			
			if(yn.equalsIgnoreCase("y")==false)break; //대소문자무시
			
			
			
		
		}//while
		
		System.out.println("---[end]---");
		
		scanner.close();

	}//main

}
