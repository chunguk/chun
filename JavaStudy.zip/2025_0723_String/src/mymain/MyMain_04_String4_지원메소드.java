package mymain;

public class MyMain_04_String4_지원메소드 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//		      012345678901234567890123456789
		String str = "I Am Tom You are Jane";
		
		//길이 구하기  
		int length = str.length();
		System.out.printf("str s length = %d\n",length);
		
		
		//검색기능 lastIndexOf
		int index = str.indexOf('a');
		System.out.printf("'a'의 위치는 %d\n",length);
		
		
		index = str.indexOf("You");
		System.out.printf("'[You]'의 위치는 %d\n",length);

		index = str.indexOf('a',10);
		System.out.printf("index 10부터 검색된 %d\n",index);
		
		//뒷쪽에서 부터
		index = str.lastIndexOf('a');
		System.out.printf("뒷쪽으로 index 10부터 검색된 %d\n",index);
		
		
		//치환기능 replace
		String str1 = str.replace("Tom", "톰");
		String str2 = str.replace("a", "에이");
		String str3 = str.replaceAll("a", "에이");//전체바꾸기
		System.out.println(str);
		System.out.printf("[원본 : [%s]\n",str);
		System.out.printf("[사본 : [%s]\n",str1);
		System.out.printf("[사본 : [%s]\n",str2);
		System.out.printf("[사본 : [%s]\n",str3);
		
		//추출기능 
		char ch = str.charAt(5);
		System.out.printf("index [%d]번쨰 문자는[%c]\n",index,ch);
		
		
		//문자추출
		String str4= str.substring(9);
		System.out.println(str4);
		//					5<= 추출범위 < 5
		String str5 = str.substring(5,8);
		System.out.println(str5);
		
		
		//반복
		String str6= "안녕".repeat(3);
		System.out.println(str6);
		
		//분리
		String str7 = "딸기 참외 수박 만두";
		
		String [] fruit_array=str7.split(" ");
		System.out.println(str7);
		//String [] fruit_array= {"딸기,참외,수박,만두"};
		
		for(int i= 0; i<fruit_array.length; i++) {
			System.out.printf("fruit_array[%d] : %s\n",i,fruit_array[i]);
		}
		
	}
	

}
