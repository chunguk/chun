package mymain;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import myutil.Jumin;

public class MyMain_Jumin {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		String jumin_no;
		String yn="y";
		
		Jumin jumin = new Jumin();
		
		/*
		 
		 * : 0 .. n
		 + : 1 .. n
		 ? : 0 or 1
		 
		 
		 
		 */
		
		
		String regular_jumin = "^(\\d{2})((0[1-9])|(1[0-2]))(([0][1-9])|([12][0-9])|(3[01]))-[1-4]\\d{6}$";
		Pattern pattern = Pattern.compile(regular_jumin);
		
		
		while(true) {
			
			
			System.out.print("주민번호(xxxxxx-xxxxxxx):");
			jumin_no = scanner.next();
			
			Matcher matcher = pattern.matcher(jumin_no);
			
			//패턴에 일치하지 않으면
			if(matcher.find()==false) {		//매치를했는데 일치하지않으면
				System.out.println("주민번호 형식이 틀립니다!!");
				continue;	//끝내고 다음제어식으로 돌아가라
			}
			
			//주민번호객체에게 번호를 넣어준다.
			jumin.setJumin_no(jumin_no);
			 if (jumin.isValid()) {
	                System.out.println("✅ 유효한 주민등록번호입니다.");
	            } else {
	                System.out.println("❌ 유효하지 않은 주민등록번호입니다.");
	            }
			 //또할래?

			
			
			
			//부가정보 추출(출생년도/나이/띠/성별.....)
			int year = jumin.getYear();
			
					System.out.printf("출생년도 : [%d] 입니다\n",year);
			
			int age = jumin.getAge();
					System.out.printf("나이는 :   [%d] 살입니다\n",age);
			
			String tti = jumin.getTti();
			
					System.out.printf("띠는 :     [%s] 입니다\n",tti);
			
			String gender = jumin.getGender();
					System.out.printf("성별은 [%s]입니다\n",gender);
			
			String region = jumin.getregion();
			System.out.printf("지역은 [%s]입니다\n",region);
					
			String season = jumin.getseason();
			System.out.printf("태어난 계절은 [%s]입니다\n",season);
			
			String ganji = jumin.getganji();
			System.out.printf("당신의 간지는 [%s년]입니다\n",ganji);
			
					
			System.out.println();
			
			
			 System.out.print("계속하시겠습니까? [y/n]");
			 yn = scanner.next();
			if(!yn.equalsIgnoreCase("n")) break; //대소문자무시 equalsIgnoreCase
			
		}//end while
		
		System.out.println("-----[end]-----");
		
		scanner.close();

	}

}
