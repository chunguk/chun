package mymain;

public class MyMain_01_String1_묵시적_명시적생성방법 {

	public static void main(String[] args) {
		
		//String : 문자열 관리하는 객체
		//1. 생성방법
		
		//1)묵시적 생성 방법
		String name1 = "홍길동";
		
		//2)명시적생성방법
		String name2 = new String("박길동");
		
//-------------------------------------------------------------------------------------------------
		
		//1묵시적 생성
		String s1 = "Twinkle";
		String s2 = "Twinkle";
		
		if(s1==s2) {	//같은 램주소를 갖고있어서 같다고 나옴
			System.out.println("--Same--"); 
		}else
			System.out.println("--Diff--");
		
		
//----------------------------------------------------------------------------------------------------		
		
		//2명시적 생성방법
		String s3 =new String("Little Star");
		String s4 =new String("Little Star");
		
		if(s3.equals(s4))
			System.out.println("--Same--");
		else System.out.println("--Diff");
	}

}
