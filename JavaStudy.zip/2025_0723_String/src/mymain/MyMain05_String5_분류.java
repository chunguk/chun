package mymain;

import java.util.StringTokenizer;

public class MyMain05_String5_분류 {

	public static void main(String[] args) {
			
		String sido_list = "서울#경기#인천##대전#광주#목포#대구#부산#제주";

		//문자열을 분리하는 객체
		System.out.println("---[StringTokenizer]---");  //얘는 토큰 기준
		StringTokenizer st = new StringTokenizer(sido_list,"#");	//분리 기준은 공백
		while(st.hasMoreTokens()) {	//현재 토큰 가지고 있냐? 없을때까지 와일문 계속 돌아감
			
			
			String token = st.nextToken();   //현재위치의 토큰 가져오기->다음위치로 이동
			System.out.println(token);
		
		}//while
		
		//split 메소드를 이용해서 분리
		//String []sido_array = {"서울" , "경기","인천","대전","광주",....
		String []sido_array = sido_list.split("#"); //#기준으로
		System.out.println();
		System.out.println("---[String의split]---");
		
		for(String hello : sido_array) {
			System.out.println(hello);
		}

	}

}
