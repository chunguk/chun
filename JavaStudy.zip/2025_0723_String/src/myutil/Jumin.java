package myutil;

public class Jumin {

	private String jumin_no;

	public String getJumin_no() {
		return jumin_no;
	}

	public void setJumin_no(String jumin_no) {
		this.jumin_no = jumin_no;
	}
	//			 0123456789123 < index
	//jumin_no = 991212-1234567
	
	
	/*
	 
	 성별코드
	 			내국인	외국인
	 			남	녀	남	녀
	 1900		1	2	5	6
	 2000		3	4	7	8
	 1800		9	0
	 

	 
	 */
	
	

	//출생년도 구하기
	public int getYear() {
		
		String str_year = jumin_no.substring(0,2);// "99";
		//String -> int변환
		int year = Integer.parseInt(str_year);// "99" -> 99
		
		char ch_gender = jumin_no.charAt(7);// '1' 주민번호7번째 따옴
		//숫자형 문자 -> 숫자로 변환방법
		
		int gender 		= ch_gender -'0'; //'0' :48  '1':49 '2':50
		//		문자대문자빼서	'49' - '49' = 1숫자1이됨
		
		
		switch(gender){
		
		case 1: case 2: case 5: case 6: year+=1900; break;
		case 3: case 4: case 7: case 8: year+=2000; break;
		default : year= year + 1800;
			
			
		}

		return year;

	}//년도
	

	public String getTti() {
		
		 int year = getYear(); // 출생년도 
		    String[] tti = {
		        "원숭이", "닭", "개", "돼지", "쥐", "소",
		        "호랑이", "토끼", "용", "뱀", "말", "양"
		    };

		    return tti[year % 12] + "띠";
	}
	
	
	public int getAge() {
		
		int age = 2025-this.getYear() ;
		
		return age;
	}
	
	public String getGender() {
		char ch_gender = jumin_no.charAt(7);// '1' 주민번호7번째 따옴
		
		//숫자형 문자 -> 숫자로 변환방법
//		char gender 		= ch_gender -'0'; //'0' :48  '1':49 '2':50
		//		문자대문자빼서	'49' - '49' = 1숫자1이됨
	    int gender = ch_gender - '0';        // 문자 → 숫자 변환

		switch(gender) {
		case 1: case 3: case 5: case 7: case 9:
			
			return "남성";
		case 2: case 4: case 6: case 8:
			System.out.println("성별은 여성입니다");
			return "여성";
		default :
			return "잘못된 성별코드입니다.";
		
		}

	}
	
	public String getregion() {
		int regionCode =  Integer.parseInt(jumin_no.substring(8,10));
		 if (regionCode >= 0 && regionCode <= 8) return "서울";
		    else if (regionCode <= 12) return "부산";
		    else if (regionCode <= 15) return "인천";
		    else if (regionCode <= 25) return "경기";
		    else if (regionCode <= 34) return "강원";
		    else if (regionCode <= 39) return "충북";
		    else if (regionCode <= 47) return "대전/충남";
		    else if (regionCode <= 54) return "전북";
		    else if (regionCode <= 66) return "광주/전남";
		    else if (regionCode <= 70) return "대구/경북";
		    else if (regionCode <= 80) return "경남";
		    else if (regionCode <= 84) return "제주";
		    else return "기타/해외";

	}
	
	
	public String getseason() {
		String str_month = jumin_no.substring(2,4);
			
		int month = Integer.parseInt(str_month);//문자를 숫자로변환
//		int month = Integer.parseInt(str_month.substring(2,4));//문자를 숫자로변환
			
			if(month >=3 && month <= 5) {
				return "봄";
			}else if (month >= 6 && month <=8) {
				return "여름";
			}else if (month >=9 && month <= 11) {
				return "가을";
			}else if (month == 12 || month  == 1|| month == 2 ) {
				return "겨울";
			}else  return "잘못된입력입니다";
		
	}
	
//	public String getseason() {
//		String str_month = jumin_no.substring(2,4);
//		
////		int month = Integer.parseInt(str_month);//문자를 숫자로변환
//		int month = Integer.parseInt(str_month.substring(2,4));//문자를 숫자로변환
//		
//				switch(month/3) {
//				case 1: return "봄";
//				case 2: return "여름";
//				case 3: return "겨울";
//				}
//		return "겨울";
//	}
		
	public String getganji() {
		
		 int year = getYear(); // 출생년도 
		    String[] ganji = {
		        "신", "유", "술", "해", "자", "축",
		        "임", "묘", "진", "사", "오", "미"
		    };

		    String[] 천간 = {"갑","을","병","정","무","기","경","신","임","계"};
		    
		    
		    return 천간[year %10] + ganji[year % 12];
	}	
	
	public boolean isValid() {
	    // 하이픈(-) 제거
	    String jumin = this.jumin_no.replace("-", "");

	    if (jumin.length() != 13) {
	        return false; // 13자리가 아니면 잘못된 주민번호
	    }

	    int sum = 0;
	    int[] weights = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5};

	    for (int i = 0; i < 12; i++) {
	        int digit = jumin.charAt(i) - '0';
	        sum += digit * weights[i];
	    }

	    int checksum = (11 - (sum % 11)) % 10;

	    int lastDigit = jumin.charAt(12) - '0';

	    return checksum == lastDigit;
	}
	
	
	

	
	
	
	
	
}
