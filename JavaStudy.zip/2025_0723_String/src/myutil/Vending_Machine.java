package myutil;

public class Vending_Machine {
	
	public static int COLA_PRICE 	= 2000;
	public static int CYDER_PRICE	= 1800;
	public static int JUICE_PRICE	= 2500;
	public static int MILK_PRICE 	= 2300;
	
	int money;
	int drink;
	
	//음료이름 가격배열			 0	   1	  2	      3      4
	String [] drink_name = {" ","콜라","사이다","쥬스","우유"};
	//						0    1           2           3          4
	int [] drink_price   = {0,COLA_PRICE,CYDER_PRICE,JUICE_PRICE,MILK_PRICE};;
	
	public void insertCoin(int money) {
		this.money = money;
		
		
		
	}//money
	
	public void selectDrink(int drink) {
		this.drink = drink;
		
	}//drink
	
	public void displayResult1() {
		if(drink_price[drink]>money) {
			
			System.out.println("잔액이 부족합니다");
			return;
		}
		System.out.println("---[결과]---");
		System.out.printf("받은 금액은 : %d\n",money);
		System.out.printf("선택음료 : %s(%d)\n",drink_name[drink],drink_price[drink]);
		System.out.printf("거스름돈 : %d\n",money - drink_price[drink]);
		
	}	
	
	

	
	
	
	
	
//	public void displayResult() {
//		String drinkname = "";
//		int price =0;
//		
//
//		
//		switch(drink) {
//		case 1 : 
//			drinkname = "콜라";
//			price = COLA_PRICE;
//			break;
//			
//		case 2 :
//			 drinkname = "사이다";
//			 price = CYDER_PRICE;
//			 break;
//			 
//		case 3 :
//			drinkname = "쥬스";
//			price = JUICE_PRICE;
//			break;
//		case 4:
//			drinkname = "우유";
//			price = MILK_PRICE;
//			break;
//		default :
//			System.out.println("잘못된 입력입니다");
//			return;
//		}
//		
//		System.out.println("받은금액은 " + money + " 입니다");
//		System.out.println();
//		System.out.println("선택한 음료는 " + drinkname +"가격은 " + price+"원 입니다" );
//		
//		if(money >=price) {
//			System.out.println();
//			System.out.println("거스름돈은 "+(money-price)+"원 입니다");
//
//		}else System.out.println("금액이 부족합니다 다시 확인해주세요");
//		System.out.println();
		
	}//display


	
	
	


