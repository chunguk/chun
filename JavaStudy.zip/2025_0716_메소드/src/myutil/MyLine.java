package myutil;

import java.util.regex.Pattern;

public class MyLine {

	//Call By Name 이름만 이용해서 호출
	public static void drawLine() {
		
		System.out.println("----------------------------------------");

		return;// 
	}
	
	//2개 메소드 관계
	//method Over load(중복오버로드)drawLine 이름이 같아서 중복함수
	//메소드명 동일하나 + 호출인자정보가 다른 메소드

	//Call By Value [값을 넘겨서 호출]
	public static void drawLine(int len) { //총갯수는 렝스
		
		
		
		for(int i=0; i<len; i++) {
			
			System.out.print('-');
		}		
		
		System.out.println();//줄바꾸기
	}
	
	
	//Call By Value					그리기 모양   길이
	public static void drawLine(char pattern, int len) { 
		
		
		for(int i=0; i<len; i++) {
			
			System.out.print(pattern);
		}		
		
		System.out.println();//줄바꾸기
	}
	
	
	
	// MyLine drawLine('*',1,'-',2,10)
//	public static void drawLine(char pattern1, int len1, char pattern2,int len2, int len) {
//        
//		// 여기서 pattern1과 pattern2, len2를 사용해서 "*--"과 같은 패턴을 직접 만듭니다.
//        // 예를 들어, drawLine('*', 1, '-', 2, 10)을 호출하면
//        // 'pattern1'은 '*'이고 'pattern2'는 '-'이며 'len2'는 2가 되므로,
//        // 실제로는 이런 모양을 반복하고 싶다는 뜻이 됩니다: pattern1 + (pattern2 * len2)
//        // 즉, '*' + ('-' * 2) = "*--"
//
//        // 반복할 패턴의 '길이'를 계산합니다.
//        // pattern1 (1칸) + pattern2 (len2 칸)
//		
//        int customLength = 1+ len2; // 예 1(for '*') + 2 (for '--')=3
//	
//	
//		//총길이(len)에 도달할 때가지 한 칸씩 문자를 출력
//		for(int i=0; i<len; i++) {
//			
//			//현재 i번째 칸에 어떤 문자를 출력할지 결정한다
//			
//			//i를 우리가 만든 패턴 길이로 나눈 나머지를 사용해서
//			
//			//패턴의 첫 번째 문자, 두 번째 문자 등을 반복해서 가져옵니다.
//			int charIndex = i % customLength;
//			
//			if(charIndex == 0) {
//				//패턴의 첫 번째 위치(인덱스0)일 떄는 pattern1을 출력
//				System.out.print(pattern1);
//			} else {
//				//패턴의 나머지 위치 (인덱스 1부터 len2까지)일 떄는 pattern2를 출력
//				System.out.print(pattern2);
//			}
//			
//		}
//        	System.out.println(); // 한 줄을 다 그린 후 다음 출력을 위해 줄 바꿈
//
//	}
//	
	public static void drawLine(char pattern1, int len1, char pattern2,int len2, int len) {
		
		int count=0;
	while(true) {
		
		//패턴1출력
		for(int i=0; i<len1; i++) {
			System.out.print(pattern1);
			count++;
			
			if(count >= len) { //길이 만큼 출력완료
				System.out.println();
				return;		// 메서드 종료돌아가라
			}
		}
		
		//패턴2출력
		for(int i=0; i<len2; i++) {
			System.out.print(pattern2);
		}	count++;
		
			if(count==len) { //길이 만큼 출력완료
				System.out.println();
				return;		//돌아가라
		}
		
		
		
	}//while
		
		
		
	}//Line
	
	
	public static void drawLine2(char pattern1, int len1, char pattern2,int len2, int len) {
		
		for(int i=0; i<len; i++) {		//012012012012
			if(i%(len1 + len2) < len1)  //1 % 3 < 1 = 0밖에없네
				System.out.print(pattern1);
			else System.out.print(pattern2);
		}
		
		
		
		
		
	}//Line 2	
	
	
	
	
	
}//클래스의끝
