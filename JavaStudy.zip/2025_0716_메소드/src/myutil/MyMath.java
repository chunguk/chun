package myutil;

public class MyMath {
								
	//Method Overload 요건 : 호출(인자)정보가 틀려야 함
	
	
		//2수중에 큰수
		public static int max(int a, int b) {
			
			
			return(a>=b) ? a: b;
		}

		//3수중에 큰수
		public static int max(int a, int b, int c) {
	
	
			return 0;
		}
		
		
		//1~n까지의 합
		
		public static int hap(int n) {
			
			int sum =0;
			for(int i=1; i<=n; i++) {
				sum = sum + i;
			}
			
			return sum;
		}
		
		//재귀호출을 이용한 합 구하기
		public static int hap_recursive(int n) {
			
			if(n==0) return 0;
			
			return n + hap_recursive(n-1);
			//자신의 메소드를 호출하는 재귀호출이라고 한다.
		}
		
		
		
		//1~(n)까지의 (m)의 배수의 합
		public static int hap(int n,int m) {
			
			int sum =0;
			for(int i=1; i<=n; i++) {
				if (i %m ==0) {//m의 배수인지 확인
					sum = sum + i;
				}
			}
			
			
			return sum;
			
			
			
				
		}
		
		//1~n까지의 홀수의 합
		public static int odd_hap(int n) {
			int sum =0;
			for(int i=1; i<=n; i++) {
				if(i %2==1) {
					sum = sum + i;
				}
			}
			
			
			return sum;
		}
		
		//factorial : 4!= 4*3*2*1
		public static double factorial(int n) {
			double fac=1;
			
			for(int i=1; i<=n; i++) {
				fac = fac *i;
			}
			
			return fac;
			
			
			 //더블형이라 소수점붙임
		}
		
		//m의 s n승을 구하라
		public static double pow(int m, int n) {
			double result =1;
			
			for(int i=0; i<n; i++) {
				result = result * m;
			}
			
			
			return result;
		}
		
		
		//솟수의합
		
		public static int prime(int n) {
		  int sum = 0;

		    for (int i = 2; i < n; i++) {
		        int count = 0;  // 약수의 개수를 세기 위한 변수

		        for (int j = 1; j <= i; j++) {
		            if (i % j == 0) {
		                count++; // 약수를 찾으면 count 증가
		            }
		        }

		        if (count == 2) { // 약수가 1과 자기자신뿐이면 소수
		            sum = sum + i;
		        }
		    }

		    return sum;
		}

		
		
		public static int prime1(int a) {
			
			int sum =0;
			
			
			OUT_FOR:
				for(int i=2; i<=a; i++) {
					
					//솟수체크
					for(int k=2; k<=(i/2); k++) {
						//솟수면 i++로 이동시킨다
						if(i%k==0)continue OUT_FOR;
//						System.out.println(i);
						//아니면누적
						sum+=i;
					}
					
				}
		    return sum; // 최종 합 반환

		}
		
		
		
		
		
		
		

}