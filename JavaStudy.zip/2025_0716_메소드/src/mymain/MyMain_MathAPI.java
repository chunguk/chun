package mymain;

import myutil.MyMath;

public class MyMain_MathAPI {

	public static void main(String[] args) {
		
		
		int a=4;
				;
		int b=15;
		
		int c=3;
		
		int result;
		
		double result1;
		
		//기존API
		result = Math.max(a, b);
		
		System.out.printf("%d,%d중에 큰수는%d\n",a,b,result);
	
		result = Math.min(a, b);
		
		System.out.printf("%d,%d중에 작은수는%d\n",a,b,result);
		
		
		System.out.println("-------------[내가만든API]------------");
		
		//내가만든 메소드
		
		result =MyMath.max(a, b);
		System.out.printf("%d,%d중에 큰수는= %d\n",a,b,result);
		
		result =MyMath.max(a, b,c);
		System.out.printf("%d,%d중에 큰수는= %d\n",a,b,c,result);
		
		
		
		result = MyMath.hap(b);
		System.out.printf("1에서~%d까지의 합은 %d\n", b, result);
		
		
		result =MyMath.hap(b,c);
		System.out.printf("1~%d까지 수중에서%d 배수합은%d\n",b,c,result);
		
		result = MyMath.odd_hap(b);
		System.out.printf("%d의 홀수 합은%d\n",b,result);
		
		result1 = MyMath.factorial(b);
		System.out.printf("%d의 팩토리얼 합은 %.1f\n",b,result1);
		
		
		result1 = MyMath.pow(b,c);
		System.out.printf("%d의 %d 제곱승은 %.1f입니다\n",b,c,result1);
		
		result= MyMath.prime(b);
		System.out.printf("%d의 소수의 합은%d입니다\n",b,result);
		
		result= MyMath.prime1(b);
		System.out.printf("%d까지 솟수의 합은%d\n",b,result);
		
		
		
		
		
		
		
		
		
		
		
		
		

	}//main

}
