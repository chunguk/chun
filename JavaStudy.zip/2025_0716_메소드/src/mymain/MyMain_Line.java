package mymain;

import myutil.MyLine;

public class MyMain_Line {
	
 /*
  * 
	메소드 호출방법에 따른 분류
	1.Call By Name
	2.Call By Value
	3.Call By Reference
	
	
	
 */
	public static void main(String[] args) {
		
		System.out.printf("%17s\n","[성적관리]");
		
		//선길이
//		int line_length= 50;
		
//		MyLine.drawLine('=',line_length);	//MyLine.drawLine('*',50);
//		System.out.println("-------------------------------------");
		System.out.println("    번호  이름   국어 영어 수학 총점 평균");
//		MyLine.drawLine('#',line_length);
		System.out.println("     1   홍길동   99   88   77   297  86");
		System.out.println("     2   황길동   99   88   77   262  86");
		System.out.println("     3   조길동   99   88   77   444  86");
		MyLine.drawLine('*',1,'-',3,30);
		System.out.println("    소개          297  262  444  777  88");
		MyLine.drawLine2('*',1,'-',2,30);

		
	//패턴
	//[*--]*--*--*--*--*--*--*--*--*--*--*--*--*
	//[**--]**--**--**--**--**--**--**--**--**--	
	//[*-]*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
		
		
	}//main

}
