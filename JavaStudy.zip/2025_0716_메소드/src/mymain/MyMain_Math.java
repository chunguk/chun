package mymain;

import myutil.MyMath;

public class MyMain_Math {
	
	
	//	static은 미리 다 만들어 놓음(자주쓰면ㄱㅊ음)
	//접근제한자 static(정적)반환형 메소드명{인자1(변수),인자2(변수)}
	public static int plus(int a,int b) {
							// int a =x  int b= y  //가인자
		int c = a + b;
		
			return c;
	}
	

	public static void main(String[] args) {
		
		
		int x = 10,y=5;
		int result;	
		
		//		클래스명.메소드명();
		//같은클래스에있으면 클래스명은 생략가능
		result = MyMain_Math.plus(x,y);
		
		System.out.printf("%d + %d = %d\n",x,y,result);
		
		result = Math.max(x, y); //실인자

		
		result  = MyMath.hap_recursive(x);		
		System.out.printf("%d까지의 합=%d\n",x , result);
		
		
		return;
	
	}//End main

}
