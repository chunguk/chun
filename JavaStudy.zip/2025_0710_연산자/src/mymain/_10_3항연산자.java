package mymain;

import java.util.Random;

public class _10_3항연산자 {

	public static void main(String[] args) {
		//3항연산자의 형식은
		
		//형식 ) (조건이) ? 참값 : 거짓값
//						  참이값 : 거짓이면
		
		//랜덤발생객체
		Random random = new Random();
		
		
		//랜덤발생해서 넣어라
		int a = random.nextInt(10)+1; 	// bound : 경우의수 0base 항상 0부터라 +1을해줘야 1~10이나옴
		int b = random.nextInt(10)+1; 	// bound : 경우의수 0base 항상 0부터 

		int result = (a > b) ?  a : b ;
		System.out.printf("%d,%d중 큰수는 %d입니다\n",a, b, result);
		
		
		
	}

}
