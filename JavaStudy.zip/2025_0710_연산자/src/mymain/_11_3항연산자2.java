package mymain;

import java.util.Scanner;

public class _11_3항연산자2 {
	public static void main(String[] args) {
		
		int kor;
		String grade = "F";
			
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("국어점수를입력하세요");
			kor = scanner.nextInt();
			
			//0~100사이냐?
			if(kor >= 0 && kor <= 100){
				
				grade = (kor>=96) ? "A+":
						(kor>=93) ? "A" :
						(kor>=90) ? "A-":
						(kor>=86) ? "B+":							
						(kor>=83) ? "B" :							
						(kor>=80) ? "B-":
						(kor>=76) ? "C+":
						(kor>=73) ? "C" :
						(kor>=70) ? "C-":
						(kor>=60) ? "D" :"F";
				System.out.printf("국어점수 :%d(점) 등급:%s\n",kor , grade);
			}else {
				System.out.println("잘못된 성적이 입력되었습니다.");
			}
			
			
			
			
			
			
			scanner.close();
		
		
		
		
		
	}
}
