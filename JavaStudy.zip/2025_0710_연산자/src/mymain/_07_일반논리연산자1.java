package mymain;

public class _07_일반논리연산자1 {

	public static void main(String[] args) {
		
		//일반논리연산자 : &&(and)  ||(or)  ! (not)
		
		System.out.println("----[ && ]----");
		System.out.printf("true && true : %b\n", true && true);
		System.out.printf("true && flase : %b\n", true && false);
		System.out.printf("flase && flase : %b\n", false && false);
		
		System.out.println("----[ || ]----");
		System.out.printf("true  || true : %b\n", true || true);
		System.out.printf("true  || flase : %b\n", true || false);
		System.out.printf("flase || flase : %b\n", false || false);
		
		
	}

}
