package mymain;

public class _08_일반논리연산자2 {

	public static void main(String[] args) {
	//평균점수가 60  각과목 40점이 넘어야함
	
	
	int 컴퓨터개론 		=60;
	int 데이터베이스	=60;
	int 운영체제		=60;
	int 네트워크		=60;
	
	//합격조건
	//조건1. 각 과목별 과락점수를 넘어야한다(40점이상)
	//조건2. 평균점수가 60점 이상
	
	
	boolean bCondition1 =(컴퓨터개론>=40 && 데이터베이스>=40 && 운영체제 >=40 && 네트워크 >=40); //조건1
	
	double avg = (컴퓨터개론 + 데이터베이스 + 운영체제 + 네트워크)/4.0; //평균내기
	
	boolean bCondition2 = (avg>=60);
	
	
	if (bCondition1 && bCondition2) {
			System.out.printf("합격: %.1f(점) 합격입니다.",avg);
		}else {
			System.out.print("불합격");
		}if(bCondition1 == false) {
			System.out.println("과목중 과락된 과목이 있습니다.:불합격");
		}else {
			System.out.println("평균점수가 60점 미만입니다 :불합격");
		}
	
	
	
	}
	
}
