package mymain;

import java.util.Scanner;

public class _21_문제2 {

	public static void main(String[] args) {
		
		//Q1. 이름을 숫자로 출력
		
		//Q2. 온도 변환 화씨<->섭씨 
		//C°= (F- 32) x 5/9  : 화씨 > 섭씨
		//F°= (C x 9/5) + 32 : 섭씨 > 화씨
		
		char ch  = '황';
		char ch1 = '춘';
		char ch2 = '국';
		
		
		System.out.printf("%c의 UTF-16 인코딩 값 %d입니다.\n",ch,(int)ch);
		System.out.printf("%c의 UTF-16 인코딩 값 %d입니다.\n",ch1,(int)ch1);
		System.out.printf("%c의 UTF-16 인코딩 값 %d입니다.\n",ch2,(int)ch2);
		
		System.out.println((int)'황');
		System.out.println((int)'춘');
		System.out.println((int)'국');
		
		System.out.println((char)54889 +""+ (char)52632 + (char)44397);
		System.out.println((char)52632);
		System.out.println((char)44397);
		
		
		
		
	}

}
