package mymain;

public class array {

	public static void main(String[] args) {
		int iArray[] = {1,2,3,4,5,6,7,8,9,10};
			
		int sum =0 ;
			for(int i=0; i < iArray.length; i++) {
					if(iArray[i] <= 10 ) {
						sum = sum + iArray[i];
					}
			}
			
			
		System.out.println(sum);
		
		
	}

}
