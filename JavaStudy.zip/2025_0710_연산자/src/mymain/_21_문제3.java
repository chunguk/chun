package mymain;

import java.util.Scanner;

public class _21_문제3 {

	public static void main(String[] args) {
		
		//Q1. 이름을 숫자로 출력
		
		//Q2. 온도 변환 화씨<->섭씨 
		//C°= (F- 32) x 5/9  : 화씨 > 섭씨
		//F°= (C x 9/5) + 32 : 섭씨 > 화씨
		
		Scanner scanner = new Scanner(System.in);
		double c ;
		System.out.println("섭씨 온도를 입력하세요");
		c = scanner.nextDouble();
		
//		double f = (c - 32) * 5.0/9.0;
		double f = (c * 1.8) + 32;
		
		System.out.printf("입력한 섭씨온도의 화씨 값은 %.1fF°\n",f);
		
		
		
		
		
		
		
		
		
		scanner.close();
		
		
	}

}
