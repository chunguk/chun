package mymain;

public class _04_관계연산자 {

	public static void main(String[] args) {
	
		
		int a =3;
		int b =2;
		
		System.out.printf("%d > %d = %b\n", a, b , a>b );
		System.out.printf("%d >= %d = %b\n", a, b , a>=b );
		System.out.printf("%d < %d = %b\n", a, b , a<b );
		System.out.printf("%d <= %d = %b\n", a, b , a<=b );
		
		System.out.printf("%d == %d = %b\n", a, b , a==b ); //같냐
		System.out.printf("%d != %d = %b\n", a, b , a!=b );	//같지않냐
	}

}
