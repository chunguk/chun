package mymain;

import myutil.MyInteger;

public class _03_쉬프트연산자 {

	public static void main(String[] args) {
		
		
		int n = 10;
		System.out.printf("[%32s]:n\n", MyInteger.toBirnaryString(n));
		System.out.printf("[%32s]:n>>\n", MyInteger.toBirnaryString(n>>2));
		System.out.printf("[%32s]:n<<\n", MyInteger.toBirnaryString(n<<2));
		
		n = -1;
		System.out.printf("[%32s]:n\n", MyInteger.toBirnaryString(n));
		System.out.printf("[%32s]:n<<\n", MyInteger.toBirnaryString(n>>4));
		System.out.printf("[%32s]:n<<\n", MyInteger.toBirnaryString(n<<4));
		

	}

}
