package mymain;

import java.util.Scanner;

public class _09_일반논리연산자4 {
	public static void main(String[] args) {
		
		//1.년도를 입력받는다
		//2.윤년/평년 구한다  400의배수가 윤년 4의배수이면서 100의배수는 아니어야한다
		//년도 %/400
		
		
		int year;
		
		
		//조건1: 연도의 400의배수 
		//조건2; 4의배수이면서 100의 배수가 아닌년도
		
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("년도를 입력하세요");
		year = scanner.nextInt();
		
		
		
		
		boolean 조건1= (year %400==0);
		boolean 조건2= (year %4 == 0 && year %100 != 0);
		
		if(조건1 || 조건2) {
			System.out.printf("[%d년도는] 윤년입니다.",year);
		}else {
			System.out.printf("[%d년도는] 평년입니다",year);
		}
		
		
		
		
		
		
		scanner.close();
		
		
		
	}
}
