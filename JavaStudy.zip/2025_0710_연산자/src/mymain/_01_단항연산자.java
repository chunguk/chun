package mymain;

import myutil.MyInteger;

public class _01_단항연산자 {

	public static void main(String[] args) {
		
		//단항 연산자 : ~ ! ++ -- (cast) -(부호)
		
		//~(tilled) : 이진논리 Not 연산자 (1의 보수)
		
		int n = 10;
		
		System.out.printf("[%32s]\n", MyInteger.toBirnaryString(~n));
		System.out.printf("[%32s]\n", MyInteger.toBirnaryString(~n));
		
		n=0xf0f0f0f0;  //0x2진수로바꾸기
		//  f = 1111 0 = 0000
		System.out.printf("[%32s]\n", MyInteger.toBirnaryString(~n));
		System.out.printf("[%32s]\n", MyInteger.toBirnaryString(~n));
		
		// ! : 일반논리 Not 연산자
		int a =3, b=2;
		
		boolean bOk = !(a>b);
		System.out.printf("!(%d > %d) : %b\n",a,b,bOk);
		
		// ++ ==    : 중(감)  연산자
		// ++변수   : 전위형 (모든연산에 앞서 먼저연산)
		//   변수-- : 후위형 (모든연산종료후 나중에 연산수행)
		int m = 10;
		
		System.out.printf("++m : %d  m++ : %d\n", ++m,m++);
		
		//형변환(Type Conversion)
		/*
				1.자동형변환(promotion)
				1)대입(치환)시 
					변수=값
					(좌)=(우)
					좌변항의 타입으로 맞춰진다 (조건: 좌 > 우) 좌변항이 우변항보다 커야된다
					
				2)연산시 : 자료형이 큰쪽으로 맞춰진다
				1+1.0 => 1.0 + 1.0
				byte + byte    -> int
				short + short  -> int
				byte + short   -> int
				int형보다 작은 자료형끼리의 연산결과는 int
				연산전에 모두int형으로 변환시킨후에 연산수행
				
				byte + int ->  int
				int + long -> long
				long + float -> float
				
				
				
		*/
		
		
		//1.자동/대입시형변환
		double d =100;	//int - > double : 100->100.0
		
		
		//2. 자동/연산시험변환
		byte b1=1,b2=2,b3;
		b3 = (byte) (b1 + b2);
		
		//3. 강제 형변환
		float f = (float)1.0;
		
		//부호 연산자 
		int x = -100;
		int y = (x < 0) ? -x : x ;
		
		System.out.printf("|%d| =%d\n", x , y);
		
		
	}

}
