package mymain;

public class _02_산술연산자 {

	public static void main(String[] args) {
		//산술연산자
		//		*  /  %
		//      +  -
		
		int a = 10  , b = 3;
		System.out.printf("%d + %d = %d\n", a,b,(a+b));
		System.out.printf("%d - %d = %d\n", a,b,(a-b));
		System.out.printf("%d * %d = %d\n", a,b,(a*b));
		
		//몫을구하는 연산자 10을 3으로 나눠서 3이 나오고 나머지가 1
		System.out.printf("%d / %d = %d\n", a,b,(a/b));
		
		//나머지 구하기 printf에서  %는 항상 서식으로 인식
		//printf에서 %를 문자로 인식시키려면 %% ->% 두개붙여쓰면된다
		System.out.printf("%d %% %d = %d\n", a,b,(a%b));

		System.out.println(10.0/3.0);
		System.out.println((int)(10.0/3.0));
		System.out.println(Math.floor(10.0/3.0)); //Math.floor소수점짜르는
		
		
		//피젯수%젯수 : 젯수>피젯수 => 피젯수
		System.out.println(5%10);
		
		
		
		
	}

}
