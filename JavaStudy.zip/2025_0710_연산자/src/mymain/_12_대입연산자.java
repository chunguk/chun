package mymain;

public class _12_대입연산자 {

	public static void main(String[] args) {
		
		int n = 10;
		
		n++;  // n= n + 1; 11
	
		n+=2; // n= n + 2;  13
		
		n*=2; // n =n * 2;  26

		n>>=1; // n = n>>1; //26/1(비트승)으로  n>>1(비트승) 답은 13
		
		int x = 1;
		int y = 2;
		
		//	&  (2진 논리 AND)
		//	&& (일반논리 AND)
		
		boolean bResult = --x >0 &&  ++y > 0;
		
		// x = 0 y =2 bRsult = false
		//경제적 연산으로 --x > 0 이거부터 맞지 않으므로 y는 +가안됨 그래서 2
		
		System.out.printf("x = %d y= %d bResult=%b\n",x,y,bResult);
		
		bResult = ++x > 0|| ++y > 0;
		System.out.printf("x = %d y= %d bResult=%b\n",x,y,bResult);

		
		
		int m =6;
		if(m %2==0 && m%3==0) {
			System.out.printf("%d은 2와 3의의 배수입니다",m);
		}else {
			System.out.println("2와3의배수가 아닙니다");
		}
	}

}
