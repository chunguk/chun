package mymain;

public class _06_이진논리연산자2 {

	public static void main(String[] args) {
		
		
		int birthday = 0x19991225;
//			이진수 1999 = 0001 1001 1001 1001  하나에 
		
		System.out.printf("생년월일 : %x\n", birthday); //%x = 16진수
		
		//출생년도 추출
		int year = birthday >>> 16;
		System.out.printf("출생년도 : %x\n",year);
		
		
		//출생월 추출
		//       19991225 >>>8
		//		 00199912
		//   &   000000ff
		//		 00000012
		int month = birthday >> 8 & 0x000000ff; //내가살려놓고싶은곳만 ff로 1로채운다
		
		System.out.printf("출생월   : %02x\n", month);
		
		int day = birthday  & 0xff;
		
		
		System.out.printf("출생일   : %x\n",day);
		
		//년도 수정
		//1. 끝자리 2자리 지우기
		
		//방법1   &연산자는 0을 줘서 없앤다
		//		0x19991225
		// &	0xff00ffff
		
		//방법2 ^연산자는 값을 일부러 일치 시켜서 소거한다
		//		0x19991225
		// ^	0x00990000
//		birthday = birthday & 0xff99ffff; //방법1
		birthday = birthday ^ 0x00990000; 	//방법2
		System.out.printf("생년월일 : %x\n",birthday);
		
		//년도추가
		//	 0x19001225		0000 
		// | 0x00880000		1000
		birthday = birthday | 0x00880000; //방법1

		System.out.printf("생년월일 : %x\n",birthday);
		
		String str_birthday = "19991225";
		
		System.out.println(str_birthday.substring(0,4));//0,4 = 첨부터 4개만 가져와라
		System.out.println(str_birthday.substring(4,6));// (4,6) 4개부터 2개만 가져와라
		System.out.println(str_birthday.substring(6));	// 6자리부터 가져와라
		
		
		
		
		
		
	}

}
