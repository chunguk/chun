package mymain;

import java.util.Scanner;

public class _20_문제1 {

	public static void main(String[] args) {
		
		/*
		  
		 1. 키를 입력받는다(cm)double
		 2. 단위환산(ft/inch)  180/ 2.24 인치하면 180이몇인치인지나온다
		 
		 1 inch = 2.54cm		180/ 2.24 인치하면 180이몇인치인지나온다
		 1 ft   = 12 inch   	cm ÷ 30.48	
		
		 */
		
		double  hight;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("키를 입력하세요.:");
		hight = scanner.nextDouble();
		System.out.printf("키는 %.1fcm\n", hight);
		
		
		double inch= 2.24 ;	//180/ 2.24 인치하면 180이몇인치인지나온다
		double ft = 30.48;	//cm ÷ 30.48	
		
		System.out.printf("키를 인치로 환산하면 %.3finch\n",hight / inch);
		System.out.printf("키를 피트로 환산하면 %.3fft\n ",hight / ft);
		
		
		
		
		
		
		
		
		
		scanner.close();
		

	}

}
