package myutil;

public class MyInteger {

	public static String toBirnaryString(int n) {//2진수 출력하는 기능만들기
		
		
		StringBuffer sb = new StringBuffer();
		
		for(int i=31; i >=0; i--) {  //32번반복 Integer가 32비트
			
			sb.append(n >>> i & 1);
			
		}
		
		
		return sb.toString();
	}

}
