package mymain;

import java.io.FileReader;

public class _10_while3_file {

	public static void main(String[] args) throws Exception {
		
		//파일열기	경로가 소스파일부터 시작해야됨
		FileReader fr = new FileReader("src/mymain/data.txt");
		int count=0;
		int ch =0;
		int upper =0;
		int lower =0;
		int number =0;
		int white =0;
		int ect =0;
		int korean =0;
		int korean1 =0;
		int korean2 =0;
		
		while(true) {
			//fr위치의 문자 1개를  읽어온다
			ch = fr.read(); 
			
			
			//text파일은 끝은 항상(EOF -1)이다
			if(ch==-1)break;
			
			System.out.printf("%c",ch);
//			Thread.sleep(10);
			
			
			
			count++; //문자의갯수 와일문 돈 횟수
			
			if(ch >='A' && ch<='Z' )upper++;
			if(ch >='a' && ch<='z' )lower++;
			if(ch >='0' && ch<= '9')number++;
			if(ch==' '|| ch=='\n' || ch=='\r' || ch=='\t')white++;
			if(ch >= (int)'가' && ch<=(int)'힣' ) korean++;
			if(ch >= (int)'ㄱ' && ch<=(int)'ㅎ' ) korean1++;
			if(ch >= (int)'ㅏ' && ch<=(int)'ㅣ' ) korean2++;
			else ect++;
			
			
			//한글정규식 표현 범위 [가,힣],[ㄱ,ㅎ],[ㅏ,ㅣ]
			
		}//end while
		
		System.out.printf("\n가:%x 힣:%x",(int)'가',(int)'힣',korean);
		
		
		System.out.println("\n----------------------------------------");
		System.out.printf("대문자 :  %d(개)\n",upper);
		System.out.printf("총문자 : %d(개)\n",count);
		System.out.printf("소문자 :  %d(개)\n",lower);
		System.out.printf("숫자   :  %d(개)\n",number);
		System.out.printf("공백   :  %d(개)\n",white);
		System.out.printf("한글   :  %d(개)\n",korean);
		System.out.printf("모음   :  %d(개)\n",korean1);
		System.out.printf("자음   :  %d(개)\n",korean2);
		System.out.printf("기타   :  %d(개)\n",ect);
		
		
		//파일닫기
		fr.close(); //열면 닫아야함
	
			
			
		
		
		
		
	}//end main

}
