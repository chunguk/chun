package mymain;

import java.util.Random;

public class _01_if1 {

	public static void main(String[] args) {
		
		
		Random random = new Random();
		
		int age = random.nextInt(101); // 0~100까지 랜덤한 정수만뽑아옴
		
		String result = ""; //결과 넣기위한 변수
		
		if( age < 10) {
			result ="[아동]입니다.";
		}else if(age >=10 && age <20) {
			result = "[청소년]입니다";
		}else if(age >=20 && age <40) {
			result = "[성년]입니다";
		}else if (age >= 40 && age < 70) {
			result = "[장년]입니다";
		}else {
			result = "[노년]입니다";
		} //if 문의 끝
		
		System.out.printf("나이는 [%d]세 ",age , result);
		System.out.println(result);
	}//end of main

}
