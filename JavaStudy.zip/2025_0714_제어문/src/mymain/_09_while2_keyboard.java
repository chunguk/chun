package mymain;

import java.io.IOException;

public class _09_while2_keyboard {
												//ch= System.in.read(); 문제생기면 메인으로 처리해줘
	public static void main(String[] args) throws IOException {
		int ch;
		int count =0;
		int alpha_upper_count =0; //대문자   갯수
		int alpha_lower_count =0; //소문자   갯수
		int number_count 	  =0; //숫자문자 갯수
		int white_count		  =0; //공백,엔터(\n)(\r)Tab(\t) 눈에 안보이는 문자 
		int etc_count		  =0; //그외기타
		
		System.out.println("종료하려면 Ctrl+Z 누르세요");
		//무조건참이라 무한돌림
		while(true) {
			
			
			//키보드 버퍼로부터 1byte씩 읽어온다	엔터는 2byte
			ch= System.in.read(); 	 //입력받는 함수
			
			//EOF(End OF File) : -1			Ctrl+Z 얘가 -1
			if(ch == -1)break;		 //break : while문을 끝내라 (탈출)
			
			System.out.printf("%c",ch);
			
			count++;	// 총 문자 수 증가 입력한문자수
			
			if(ch>='A'&& ch<='Z') {alpha_upper_count++;}
			if(ch>='a'&& ch<='z') {alpha_lower_count++;}
			if(ch>='0' && ch<='9') {number_count++;}
			if(ch==' ' || ch=='\n' || ch=='\t' || ch=='\r') {white_count++;}
			else etc_count++;
			//대문자 갯수 증가
			
		}//end of while
		
		System.out.printf("입력 문자수는 %d(개)\n",count);
		System.out.printf("대문자는 %d(개)\n",alpha_upper_count);
		System.out.printf("소문자는 %d(개)\n",alpha_lower_count);
		System.out.printf("숫자문자는 %d(개)\n",number_count);
		System.out.printf("화이트문자는 %d(개)\n",white_count);
		System.out.printf("기타문자는 %d(개)\n",etc_count);
		
		System.out.println("--End--");

		
		
		/**/
		
		
		
		
	}//end of main

}
