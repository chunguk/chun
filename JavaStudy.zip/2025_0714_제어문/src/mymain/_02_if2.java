package mymain;

import java.util.Scanner;

public class _02_if2 {

	public static void main(String[] args) {
		
		String weekday; //요일을 입력받을 스트링변수선언
		
		String job="";		//일을 초기화 넣을 변수 선언
		String food="";		//음식 넣을 초기화 변수 선언
		
		Scanner scanner = new Scanner(System.in); //시스템키보드로 스캐너를 받음
		System.out.println("요일을 입력하세요");
		
		weekday = scanner.next();
		
		// ==같냐? : primitive 기본형 자료형
		// String 같은 객체형 자료형의 체크 : equals()를 사용 이퀄스
		if(weekday.equals( "월")) {
			job = "제어문 공부한다";
			food= "카레라이스";
		}
		else if(weekday.equals("화")) { //위크데이가 화요일이면?
			job = "(제어문)while문 공부";
			food = "돈까스";
		}else if(weekday.equals("수")) {
			job = "클래스(메소드) 공부한다";
			food = "햄버거";
		}
		else if(weekday.equals("목")) {
			job = "클래스(생성자) 공부한다";
			food = "피자";
		}
		else if(weekday.equals("금")) {
			job = "클래스(스태틱) 공부한다";
			food = "삼겹살";
		}
		else if(weekday.equals("토")|| weekday.equals("일")) {
			job = "휴식+게임";
			food = "떡볶이";
		}
//		else if(weekday.equals("일")){
//			job = "쉬기";
//			food = "치킨";
//		}
		System.out.printf("%s요일 일정 : %s\n 점심 : %s\n", weekday,job,food);
			
		
		
		
		
		scanner.close();
		
		
		
		
	}//end of main

}
