package mymain;

import java.util.Scanner;

public class _03_switch1 {

	public static void main(String[] args) {
		
		String fruit;				//과일 
		String result ;
		
		Scanner scanner = new Scanner(System.in);

		System.out.println("과일명을 입력하세요");
		
		fruit = scanner.next(); //공백이 필요없어서 넥스트 공백필요하면 넥스트라인
		
		switch(fruit) {
		case "수박" : result = "시원하다"; break;
		case "딸기" : result = "새콤하다"; break;
		case "망고" : result = "달콤새콤"; break;
		case "참외" : result = "달달하다"; break;
		case "사과" : result = "새콤달콤"; break;
		default : result = "궁금해";
		
		}
		//default = 해당하는 값이 없을 때 실행되는 '마지막 안전망'
		
		System.out.printf("[%s]는(은) %s\n",fruit  , result);
		
		scanner.close();
	}

}
