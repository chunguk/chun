package mymain;

import java.util.Scanner;

public class _04_swich2 {

	public static void main(String[] args) {
		
		//01 02 03 04 05 06 07 08 09 10  11  12 
		//31 28	31 30 31 30 31 31 30 31  30  31
		int month;
		int lastday;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("월을 입력하세요.");
		month = scanner.nextInt(); //스캐너에서 입력받은 값을 month에 넣음
		
		//JDK14이후버전 지원
		
		lastday = switch(month)
				{			
//					case 1,3,5,7,8,10,12 ->{ yield 31; }
						case 2 ->{yield 28;}
					case 4,6,9,11 ->{yield 30;}
					default -> {yield 31; }
			
					
		};
		
		System.out.printf("%d월은 %d일까지 있습니다\n.",month,lastday);
		
		scanner.close();

	}

}
