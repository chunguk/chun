package mymain;

public class _12_continue_break {

	public static void main(String[] args) {
		
		//break				:현재  영역의 반복문을 탈출하는 명령
		//break label 		:label 영역의 반복문을 탈출하는 명령
		
		boolean bExit =false;
		
		for(int row=0; row<5; row++) {
		
			for(int col=0; col<5; col++) {
				System.out.printf("(%d,%d)",row,col);
				if( row==2 && col==2) {
					bExit=true;
					break;
				}
			}//안쪽
			
			System.out.println();
			if(bExit)break;
			
		}//밖 for
		
		
		System.out.println("\n--for문종료--\n");
		
		
		//방법2
		OUT_FOR: //레이블
		for(int row=0; row<5; row++) {
			
			for(int col=0; col<5; col++) {
				System.out.printf("(%d,%d)",row,col);
				
				if( row==2 && col==2) {
					break OUT_FOR; //OUT_FOR영역의 반복문을 탈출한다.
				}
			}//안쪽
			
			System.out.println();
		}//for1
		System.out.println("\n방법2--for문종료--\n");
		System.out.println();

		
		//continue			:현재명령 종료하고 다음제어식으로 이동해라(현재반복문)
		//continue label	:label 영역의 반복문에 적용된다 현재명령 종료하고 레이블로 돌아가라
		
		OUT_FOR2: //label
		for(int row=0; row<5; row++) {
			
			for(int col=0; col<5; col++) {
				if( col >2) {
					System.out.println();
					continue OUT_FOR2;   //row++로 이동
				}
				System.out.printf("(%d,%d)",row,col);
				
					
				
			}//안쪽
			
				System.out.println();
		}//for1
		System.out.println("\n방법3--for문종료--");
		
		
		
		
		
	}//main

}
