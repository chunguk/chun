package mymain;

public class _30_문제 {

	public static void main(String[] args) throws InterruptedException {
		
		
		
		for(int i = 1; i<=5; i++) {

			for(int j = 1; j<=i; j++)
			
				System.out.print("*");
			
			System.out.println(" ");
			//코드의 수행상태를 시간만큼 정지시킴
			Thread.sleep(300);//1(1000)초동안 지연시킴
			
		}//end of for
		
		
			

		
		
		
		
	}//end of main

}
