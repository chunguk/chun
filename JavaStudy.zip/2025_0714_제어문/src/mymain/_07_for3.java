package mymain;

public class _07_for3 {

	public static void main(String[] args) throws InterruptedException{
			//ABCD 알파벳 출력한다
		
		for(int i = 'A'; i <='Z'; i++ ) {	// i = 65 66 67 ....  90
					System.out.printf(" %c ",i);
		}
		System.out.println();//줄바꾸기
		
		for(int i=97; i<=122; i++) {  //소문자 출력
			System.out.printf("%c",i);
		}
		System.out.println();
		
		for(int i=0; i<=25; i++) {   // 알파벳 갯수만큼 증가
			System.out.printf("%c",'A'+ i);
		}
		System.out.println();
		
		System.out.println("         ★ AbCdEf  ★ 대소-대소");
		//대소대소
		for(int i = 'A'; i <='Z'; i++ ) {	// i = 65 66 67 ....  90
				if( i %2 ==1)	//홀수면 대문자 0이남으면 짝수 1이남으면 홀수
				System.out.printf("%c",i);
				else
					System.out.printf("%c",i+32);
		}
		
				System.out.println();//줄바꾸기
		
		
			System.out.println("         ★ AbcDef  ★ 대소소-대소소");
		//대소소대소소대소소
		//AbcDefGhiJk
				int count = 0;
				
		for(int i = 'A'; i <='Z'; i++ ) {	// i = 65 66 67 ....  90
			if(count % 3 == 0)	//홀수면 대문자 0이남으면 짝수 1이남으면 홀수
			System.out.printf("%c",i);
			
			
			else System.out.printf("%c",i+32);
				
			count ++;
		}	
			System.out.println();//줄바꾸기
			System.out.println("         ★ ABC-DEF ★");
		
		//3자리마다 - 넣기		
		//ABC-DEF-GHI-JKL
			
			count = 0;
			for(int i = 'A'; i <='Z'; i++ ) {	// i = 65 66 67 - 68 69 70 - ....  90
				System.out.printf("%c",i);
				count++;
				
				
				
				if(count % 3 == 0 && i != 'Z')	//홀수면 대문자 0이남으면 짝수 1이남으면 홀수
				System.out.print("-");
				
				
			
					
			}	
				System.out.println();//줄바꾸기	
				System.out.println("         ★ A-B=C~D ★");
				
		// - = ~ - = ~ ....	
		//A-B=C~E=F~G-H=I
			count = 0;
			for(int i = 'A'; i <='Z'; i++ ) {	// i = 65 66 67 - 68 69 70 - ....  90
				System.out.printf("%c",i);
				count++;
				
				
			if( i != 'Z') {
				if(count % 3 == 1 )	//count를 3으로 나눈 나머지가1일때 1/4/7번째 글자뒤에- 출력
					System.out.print("-");
				
				else if (count %3==2)	//count를 3으로 나눈 나머지가2일때 2/5/8 뒤에 "="출력
					System.out.print("=");
				
				else if(count %3==0) 	//count를 0으로 나눈 나머지 3/6/9 3의배수일때 글자뒤에 "~"출력
					System.out.print("~");
				}
		
			}	
			
			System.out.println();//줄바꾸기			
			
			
			for(int i=0; i<=12; i++) {
			
					System.out.printf("%c",'A'+i);	//ABC DEF GHI JKL
					System.out.printf("%c",'Z'-i);	//ZXY WVU TSR RQP
					
					Thread.sleep(500);			
				
			}
				
	}//main

}
