package mymain;

import java.util.Scanner;

public class _20_문제1 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		String mbti;
		String result  ="";
		String result2 ="";
		String result3 ="";
		String result4 ="";
		
		
		System.out.println("mbti를 입력하세요");
		mbti = scanner.next().toUpperCase(); //toUpperCase 강제로 대문자로 출력해줌
		//		0123
		//mbti = "ENFP";
			
		char mbti1 = mbti.charAt(0);	//charAt(0) =n번째값을빼옴
		char mbti2 = mbti.charAt(1);
		char mbti3 = mbti.charAt(2);
		char mbti4 = mbti.charAt(3);
		
		
		 if	     (mbti1 == 'I')	{result ="내향";
		}else if(mbti1 == 'E')  {result ="외향";
		
		} 	  if(mbti2 == 'S')  {result2 ="감각";
		}else if(mbti2 == 'N')  {result2 ="직관";
		
		}if		(mbti3 == 'T') 	{result3 ="사고";
		}else if(mbti3 == 'F') {result3 ="감정";
		
		}if		(mbti4 == 'J') 	{result4 ="판단";
		}else if(mbti4 == 'P')  result4 ="인식";
		
		
		System.out.printf("당신의 %c%c%c%c는 [%s] [%s] [%s] [%s]의 지표를 가진 MBTI군요?",mbti1,mbti2,mbti3,mbti4,result,result2,result3,result4);
		
		scanner.close();
	
	
	
	//배열로 한번 뽑아보기
	
//	
//		int[] answer= {1,0,1,0};
//		//mbti를 구성할 배열
//		char[] mbti1 = new char[4];
//		
//		char[][] types = {
//				{'I' , 'E'},
//				{'S' , 'N'},
//				{'F' , 'T'},
//				{'J' , 'P'}
//			};
//		
//		for(int i =0; i <  answer.length;  i++) {
//		
//			mbti1[i] = types[i][answer[i]];
//	
//		
//		
//		}
//	
	
	
	
	
	
	
	
	
}//메인의끝
}