package mymain;

import java.util.Scanner;

public class _06_for2 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int dan;
		System.out.println("단을입력하세요");
		dan = scanner.nextInt();
		
		//입력한값을 검증
		if(dan <2 || dan >9) { //입력한 값이 2~9사이 값이 아니면
			System.out.println("dan은 2~9사이값만 입력하세요");
			return; //검증 프로그램 종료
		}
	
		
		
		for(int i= 1; i<=9; i++) {	//1~9까지 반복
			System.out.printf("%d x %d = %d\n",dan,i,dan*i);
		}
			for(int j =1; j<=9; j++)
				
				
		
		
		scanner.close();
	}

}
