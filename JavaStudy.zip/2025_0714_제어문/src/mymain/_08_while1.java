package mymain;

public class _08_while1 {

	public static void main(String[] args) {
		int n =0;
		while(n<3) {
			System.out.printf("%d<3 : %b ",n , n<3);
			System.out.println("안녕하세요");
			n++;
		}

		System.out.printf("%d<3 : %b",n,n<3);
		
		
	}

}
