package mymain;

public class _05_for1 {

	public static void main(String[] args) throws InterruptedException {
		
		int sum = 0;
		
		int n = 10;
		
		for(int i = 1; i<=n; i++) {
			
			System.out.print(i);
			
			if(i<10)
			System.out.print('+');
			
			else 
				System.out.print("=");
			
			sum= sum + i;
			
			
			//코드의 수행상태를 시간만큼 정지시킴
			Thread.sleep(300);//1(1000)초동안 지연시킴
			
		}//end of for
		
		
			System.out.println(sum);


		
		
		
		
	}//end of main

}
