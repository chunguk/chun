package mymain;

public class _21_문제2별찍기 {

	public static void main(String[] args) throws InterruptedException {

		
	for(int i=0; i<5; i++) {	
		//별다섯개찍고 앤터
		for(int k=0; k<5; k++) {
			System.out.print("*");
//			Thread.sleep(10);
		}//end j
		
		//줄바꾸기
			System.out.println();
			
		}//end i
			
	System.out.println("--------[삼각형1]--------");	
	
	
	for(int i=0; i<5; i++) {	
		//별다섯개찍고 앤터
		for(int k=0; k<5; k++) {
			
			if(k <=i)
				System.out.print("*");
			else
				System.out.print("-");
			}//end j
		
			//줄바꾸기
			System.out.println();
			
	}//end i
		
	System.out.println("--------[삼각형3]--------");	
	
	for(int i=0; i<5; i++) {	
		//별다섯개찍고 앤터
		for(int k=0; k<5; k++) {
			
			if(k>=i)
				System.out.print("*");
			else
				System.out.print("-");
			}//end j
		
			//줄바꾸기
			System.out.println();
			
	}//end i
	
	System.out.println("--------[삼각형4]--------");	
	
	for(int i=0; i<5; i++) {	
		//별다섯개찍고 앤터
		for(int k=4; k>=0; k--) {
			
			if(i>=k)  
				System.out.print("*");
			else
				System.out.print("-");
		}//end j
		
		//줄바꾸기
		System.out.println();
		
	}//end i
	System.out.println("--------[삼각형5]--------");	
	
	
	
	for(int i=0; i<5; i++) {	
		//별다섯개찍고 앤터
		for(int k=4; k>=0; k--) {
			
			if(i==k || 4-i==k)  
				System.out.print("-");
			else
				System.out.print("*");
		}//end j
		
		//줄바꾸기
		System.out.println();
		
	}//end i
	
	System.out.println("-----------[마름모6]--------");	
	

	
	int a= 5;
	int b= 5;
	
	for(int i=1; i<=5; i++) {
		for(int k=0; k<=10; k++) {
			if(k >= a && k <= b) {
				System.out.print("*");
			}else System.out.print("-");
		}
		System.out.println();
		a--;
		b++;
		

	}//end i
	
	int c=2;
	int d=8;
		for(int i=1; i<=5; i++) {
			for(int k=0; k<=10; k++) {
				if(k >= c && k <= d) {
					System.out.print("*");
				}else System.out.print("-");
					
			}//for2
			
			
			System.out.println(); //안쪽 포문 다 찍고나서 엔터
			
			
			c++;	//안쪽포문끝나고 증감
			d--;	//안쪽포문끝나고 감소
			
			
			
		}//for1
		System.out.println("-----------[역마름모6]--------");	
		
		
		
		int e= 5;
		int f= 5;
		
		for(int i=1; i<=5; i++) {
			for(int k=0; k<=10; k++) {
				if(k >= e && k <= f) {
					System.out.print(" ");
				}else System.out.print("*");
			}
			System.out.println();
			e--;
			f++;
			
			
		}//end i
		
		int z=2;
		int x=8;
		for(int i=1; i<=5; i++) {
			for(int k=0; k<=10; k++) {
				if(k >= z && k <= x) {
					System.out.print(" ");
				}else System.out.print("*");
				
			}//for2
			
			
			System.out.println(); //안쪽 포문 다 찍고나서 엔터
			
			
			z++;	//안쪽포문끝나고 증감
			x--;	//안쪽포문끝나고 감소
			
			
			
		}//for1
		
	}

}
