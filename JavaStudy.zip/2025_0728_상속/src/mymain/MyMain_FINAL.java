package mymain;

class A{
	void sub() {}
	final void final_sub() {} // final_sub 재정의 하지말어라 금지선언
}

final class B extends A{
	// Cannot override the final method from A
	void sub() {}
//	void final_sub() {}
}



//class C extends B{
	
	

	
	
public class MyMain_FINAL {

	public static final double PI = 3.14;
	//final
	//1.final int(변수)		: 상수 선언
	//2.final method		: 재정의 금지 메소드앞에 파이널걸면 재정의못함
	//3.final class			:  class앞에 붙으면 상속 금지선언
	
	
	
	public static void main(String[] args) {
		
		
		

	}

}
