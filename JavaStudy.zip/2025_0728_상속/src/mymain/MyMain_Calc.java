package mymain;

import myutil.AdvanceCalc;		//어드밴스 상속 가져옴
import myutil.BaseCalc;

public class MyMain_Calc {
	
	static void onlyBaseCalc(BaseCalc bc) {
								//BaseCalc bc = ac	<-업캐스팅됨 (권한축소)		1  2 권한
			System.out.println("---[베이스칼크]---");
			int a = 10 , b = 3, result;
			result = bc.multyply(a, b);
//			System.out.println(bc.toString());
			System.out.printf("[%d] * [%d] = [%d]\n",a,b,result);
			
			
	}

	static void onlyObject(Object ob) {
							//Object ob = ac <- 업캐스팅 자동형변환(권한축소)  1 권한
		System.out.println("---[Object 영역]---");
		System.out.println(ob.toString()); //객체정보 알려주는 .toString
		
		int n = 10 ,result;
		
		result = ((AdvanceCalc)ob).hap(n);
		//강제 형변환해서 일시 영역 확장됨 = down casting 다운캐스팅
		System.out.printf("%d까지의 합:%d\n",n,result);
		
		
		Object ob1 = new Object(); //객체생성
		
		AdvanceCalc ac = (AdvanceCalc)ob1;
			
	}
	
	
	
	public static void main(String[] args) {
		
		AdvanceCalc ac= new AdvanceCalc();	//객체 생성		1 2 3 권한
		
		Object 	  ob = ac;
		BaseCalc  bc = ac;
	
		
		onlyBaseCalc(ac);
		onlyObject(ac);
		
		
		int x = 10, y = 3;
		
		int result;
		
		result = ac.plus(x, y);
		
		System.out.printf("[%d] + [%d] = [%d]\n",x,y,result);
		
		result = ac.hap(x);
		System.out.printf("[%d]까지의 합은 [%d]\n",x,result);
		
		
		int a =2, b = 10;
		double result1= ac.pow(a, b);
		System.out.printf("[%d]승의 [%d]승 = [%.1f]\n",a,b,result1);
		
		
		result = (int) ac.pow(x,y);

		System.out.printf("[%d]의[%d]승은 [%d]",x,y,result);
		

		
		
	}//main

}
