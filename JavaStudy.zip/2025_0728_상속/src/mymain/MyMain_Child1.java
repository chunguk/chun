package mymain;

import myutil.Child1;
import myutil.Parent1;

public class MyMain_Child1 {

	public static void main(String[] args) {
		

		Parent1 p1 = new Child1();
		p1.sub();
	}

}
