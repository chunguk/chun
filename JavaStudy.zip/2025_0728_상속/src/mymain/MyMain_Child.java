package mymain;

import myutil.Child;

public class MyMain_Child {

	public static void main(String[] args) {
		
	//super		: 부모의 참조변수
	//super()	: 부모의 생성자
		
		
		
	Child c1 = new Child();
		c1.display();
	
	Child c2 = new Child(1500000);
		c2.display();
	
	
	Child c3 = new Child(1000000,3000000);
		c3.display();
	}
	
}
