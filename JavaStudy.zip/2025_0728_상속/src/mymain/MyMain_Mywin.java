package mymain;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

//AWT(Abstract Window Toolkit) : 윈도우 관련기능 정의
// Frame			<- awt
//	ㄴJFrame		<- swing

public class MyMain_Mywin extends JFrame{

	//화면해상도를 저장할 변수
	int screen_w;
	int screen_h;
	
	
	//기본생성자 == 초기화용도
	public MyMain_Mywin() {
		
		super("내가 처음 만든 윈도우");	//타이틀호출 JFRAME 생성자 호출
		
		//화면 해상도를 구하자
		Dimension   d= Toolkit.getDefaultToolkit().getScreenSize();
		
		screen_w = d.width;
		screen_h = d.height;
		
		System.out.printf("w : %d  h : %d\n",screen_w,screen_h);
		

		JButton jbt_kor = new JButton("한국어 인사말");
		JButton jbt_eng = new JButton("영어 인사말");
		JButton jbt_jpn = new JButton("일본어 인사말");
		
		//배치방법은 3행 1열로 배치
		this.setLayout(new GridLayout(3,1));
		
		//버튼추가
		this.add(jbt_kor);
		this.add(jbt_eng);
		this.add(jbt_jpn);
		
		//버튼 이벤트 처리
		
		//jbt_kor버튼이 클릭이되면 on_click_kor()호출하겠다
		jbt_kor.addActionListener((e)->{on_click_kor(); });
		jbt_eng.addActionListener((e)->{on_click_eng(); });
		jbt_jpn.addActionListener((e)->{on_click_jpn(); });
		
		
		
		
		//위치지정			x , y
		super.setLocation(300, 200);
		
		//크기지정		w	 h
		super.setSize(500, 500);
		
		//보여주기
		super.setVisible(true);
		
		//종료코드
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//크기변붉가 코드
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		//타이틀
		super.setTitle("집에 가고싶은 창");//타이틀바꾸기
		
		
		//키보드 이벤트 설정
		// Delegation Event Model(위임 이벤트 모델)
		this.addKeyListener(new MyKeyAdapter());

	}

	private void on_click_kor() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(this, "한국어 인사말 : 안녕하세요");
	}
	private void on_click_eng() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(this, "영어 인사말 : 헬로");
	}
	private void on_click_jpn() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(this, "일본어 인사말 : 오하요");
	}

	//키보드 이벤트 설정
	class MyKeyAdapter extends KeyAdapter{
		
		//키가눌렸을때 발생하는 메소드
		@Override
		public void keyPressed(KeyEvent e) {
			
			//눌린 키값
			int key = e.getKeyCode();
			int gan = 10;
//			System.out.println(e);
			
			//현재윈도우의 위치 알아보기
			Point pt = MyMain_Mywin.this.getLocation();		//Point : x, y 좌표값을 갖고 있음
			
			
		if(key==KeyEvent.VK_LEFT)  {
			pt.x -= gan;						//LEFT
		}
		else if(key==KeyEvent.VK_UP){
			pt.y -= gan;						//up
		}
		else if(key==KeyEvent.VK_RIGHT){ 
			pt.x += gan;						//RIGHT
		}
		else if(key==KeyEvent.VK_DOWN){
			pt.y += gan;						//DOWN
		}
		
		
		if(pt.x >screen_w ) {
			pt.x = -500;
		}else if(pt.y >screen_h) {
			pt.y = -500;
		}
		
		else if(pt.x < -500) {
		 pt.x =screen_w;
		}else if(pt.y <-500) {
			pt.y = screen_h;
		}
		
		//위치 고정
		setLocation(pt);
		
		
		}
	}

	public static void main(String[] args) {
		
		new MyMain_Mywin(); //()이거라 기본생성자 초기화
	}
}
