package myutil;

public class Child extends Parent{

	protected int c_money;
	
	//1.Child c = new Child();
	public Child() { //기본 생성자
		super(); //Parent() call 부모의 생성자
		System.out.println("-----[Child]-----");
		c_money = 5000000;
		
	}

	//2. Child c = new Child(2000000);
	public Child(int c_money) {	//자기가 갖고있는 c머니를 초기화 하겠다
		
		
		//슈퍼보다 앞선 명령은 있을수없습니다
		super();//부모먼저콜해라 초기화는 어떤메소드보다 최우선적으로 실행
		System.out.println("-----[Child]-----c_money");
		this.c_money = c_money;
		
//		Child c = new Child(2000000);
	}
	
	
	
	//3. Child c = new Child(1000000,2000000);
	public Child(int p_money,int c_money) {//차일드랑 부모를 둘다 초기화
		super(p_money); //Parent(p_money) call
//		super();
		System.out.println("-----Child(p_money,c_money)-----");
//		super.p_money = p_money;
		this.c_money = c_money;
		

	}
	
	public void display() {
		
		super.display();
		
		System.out.printf("Child;s money = %d\n",c_money);

		
	}
	
}
