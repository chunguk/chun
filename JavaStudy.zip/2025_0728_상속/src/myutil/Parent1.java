package myutil;

public class Parent1 {
	
	//Method Overload : 메소드명은 동일하나 인자정보가 다른 메소드
	public void sub() {
		
		System.out.println("---[Parent1.sub() cal]---");
		
	}
	public void sub(int n) {
		
	}
	
	
}//class
