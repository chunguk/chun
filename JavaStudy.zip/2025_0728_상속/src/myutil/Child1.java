package myutil;
					//상속받기
public class Child1 extends Parent1{

	//@이름  : annotation(주석 : 꼬리표)
	
	//재정의 : Method Overrid
	//			조건)1. 이름과 파라메터정보 동일해야됨
	//				 2. 접근제한자는 크거나 같아야 함
	//				 3. 오버라이드 실행은 가장마지막 재정의 된  명령이 호출됨
	@Override		//조상이랑 같은 메소드가 있음
	public void sub() {
		
		System.out.println("---Child1.sub() cal---");
		
	}
	
	
}//class
