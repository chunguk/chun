package myutil;

public class AdvanceCalc extends BaseCalc {	//조상의모든기능다쓸수있음 날로먹음

	public int hap(int n) {
		
		int sum =0;
		
		for(int i =0; i<=n; i++)
			sum = super.plus(sum, i); //sum+i;
		
//			sum = sum + i;
		
		return sum;
	}
	
	//n의 m승구하기
	public double pow(int n, int m) {
		
		
		
		double result = 1.0;
		
		for(int i=0; i<m; i++) {
				
			
			result = super.multyply(result, n) ;//result * n;
			
		}
		
		
		return result;
	}
	
	
	//정확하게 부모 메소드를 가지고올때는 super를 붙여야한다 생략불가
	
	
}//Advan
