package myutil;



public class Parent {

	protected int p_money;		//자식이쓸수있는 접근제한자 protected
		
	//Parent p = new Parent()
	public Parent() {
		super(); //Object()call
		System.out.println("-----[Parent]-----");
		p_money = 100000;
		
	}

	//Parent p = new Parent (100000)
	public Parent(int p_money) {	//외부에서p머니를 받아서 전달해주는 생성자
		super();
		this.p_money = p_money;
	}
	
	public void display() {//디스플레이 객체
		
		System.out.printf("Parent;s money = %d\n",p_money);
	}
	
	
	
}//class
