package myutil;

//	자바의 모든 객체는 Object 로 부터 상속 받는다
public class BaseCalc /* extends Object */{//4개의 기능을 갖는 계산기 클래스

	
	//퍼블릭메소드 : 기능들
	public int plus(int a,int b) {
		
		return a + b;
	}
	
	
	public int minus(int a,int b) {
		
		return a - b;
	}
	
	
	public int multyply(int a, int b) {
		
		return a *b;
	}
	
	
	public double multyply(double a, double b) {//반환값도 더블 매게변수도 더블
		
		return a *b;
	}
	
	
	public int divide(int a, int b) {
		
		
		
		return (b==0) ? 0: (a/b);
		
	}
	
	
	
	
}//class
