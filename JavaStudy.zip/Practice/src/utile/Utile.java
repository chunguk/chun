package utile;

public class Utile {
	
	public int add (int a,int b) {
		int result =0;
		
		result = a+b;
		
		return result;
		
	}
			
	
}
