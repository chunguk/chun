package mymain;

import utile.Utile;

public class MyMain {

	public static void main(String[] args) {
			Utile add = new Utile();
			
			int result = 0;
			
			result = add.add(1,2);
			
			System.out.println(result);
			

	}

}
