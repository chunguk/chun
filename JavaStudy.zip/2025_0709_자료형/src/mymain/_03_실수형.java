package mymain;

public class _03_실수형 {

	public static void main(String[] args) {
		//	일반 자료형애들은 스택메모리에 쌓이고 스택메모리는
		//상수 or NEW애들은 힙영역에 쌓인다
		
		//실수형 자료형 : float double(기본형
		//상수(리터럴)  : 1.0 1.0E + 002
		//                1.0F <- float형 리터럴
		//출력서식      : %f		        (소수점 6자리 까지 출력됨)
		//			   	: %e  %E (지수출력) (소수점 6자리 까지 출력됨)
		//				: %g     (자리수가 적은쪽으로 출력) 잘안쓰임

		double d = 1.2534;
		System.out.printf("%f\n",d);//1.253400
		System.out.printf("%e\n",d);//1.253400e+00
		System.out.printf("%E\n",d);//1.253400E+00
		System.out.printf("%g\n",d);//1.25340

		float f1 = 1.234567890123456789F;	  //소수점 7자리까지 정밀도 가짐
		double d1 = 1.234567890123456789;    //소수점 16자리 정밀도 가짐
		// %m.nf m(전체자리수) n(소수점이하자리수)
		System.out.printf("%.20f\n",f1);
		System.out.printf("%.20f\n",d1);
		
		// %정수d : 정수 -> 출력공간확보의 크기
		System.out.printf("[%30.20f]\n",d1);//소수점은 최우선으로 무조건 지켜줌
		
		
		
		
		
	}

}
