package mymain;

import java.util.Scanner;

public class _05_문제2 {

	public static void main(String[] args) {
		//조건1 : 반지름 입력받는다
		//조건2 : 원둘레 = 2* 3.14 * 반지름
		//조건3:  원면적 = 반지름 * 반지름 * 3.14
		//조건4:  구부피 = 4/3 * 파이 * 반지름3승
		//조건5 : 출력시 소수점 1자리까지만 출력 (%.1d)
		
		//반지름 입력받을 변수선언 
		double  ban;
		
		//스캐너 온
		Scanner scanner = new Scanner(System.in);
		
		//반지름입력하라는 메세지 출력후 스캐너 실수로받음
		System.out.print("반지름을 입력하세요 :");
		ban = scanner.nextDouble();

		System.out.print("*************************\n");
		
		//반지름값 프린트
		System.out.printf("반지름이 %.1f일때\n",ban);

		//반지름값 받은걸로 원둘레 계산후 출력
		double oendulre = 2 * Math.PI * ban;
		System.out.printf("원둘레는 : %.1f입니다\n",oendulre);
		
		//반지름값 받은걸로 원면적 계산후 출력
		double onemyen = ban * ban * Math.PI;
		System.out.printf("원면적은 : %.1f입니다\n",onemyen);
		
		//반지름값 받은걸로 구부피 계산후 출력  Math.pow===제곱승 신텍스에러/로지컬에러
		double circle = (4.0 / 3.0) * Math.PI * Math.pow(ban, 3);
		System.out.printf("구부피는 : %.1f입니다\n",circle);
		System.out.print("*************************\n");
		
		
		scanner.close();		
	}

}
