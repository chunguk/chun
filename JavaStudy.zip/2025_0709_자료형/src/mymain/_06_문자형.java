package mymain;

public class _06_문자형 {

	public static void main(String[] args) {
		// 문자형 자료형 : char ex 'a' (2byte code)
		// 상수(리터럴) : 'A'  '9'  '한'  '韓'
		// 출력서식      : %c
		// ASCII아스키코드(American Standard Code for Information Interchange)
		// 0~31 : 제어 및 통신문자(home end)
		//		  	\r : carriage return (Home 키)
		//		  	\n : new line (enter 키)
		//		  	\t : Tab
		//			\b : left arrow
		// 32~126: 일반문자(영문자/숫자/기호[]><...)
		//		   'A' : 65  / 'a' : 97 / '0' : 48  / ' ' : 32
		
		
		System.out.printf("%c\n",65);
		System.out.printf("%c\n",'a');

		
		
		char ch = '황';
		char ch1 = '춘';
		char ch2 = '국';
	
		
							                   	//(타입)강제 형변환
		System.out.printf("%c s code : %d\n",ch ,(int)ch);
		
		System.out.printf("%c%c%n%c%n", ch,ch1,ch2);
		
		
		
		// %n : 자바에서 운영체제에 맞게 해석 처리
		// \n : 있는 그대로 해석
		//윈도우에서 엔터는    : \r\n
		//맥(유닉스계열)에서는 : \n 
		
		System.out.println("A\nB\nC\n");
		System.out.println("A\tB\tC\n");
		System.out.println("ABC\bB\tC\n");
		
	}

}
