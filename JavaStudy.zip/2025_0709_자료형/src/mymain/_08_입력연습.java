package mymain;

import java.util.Scanner;

public class _08_입력연습 {

	public static void main(String[] args) {

		String name;
		int age;
		String addr;
		double hight;
		boolean bMarried;
		char gender;

		Scanner scanner = new Scanner(System.in);
		//키보드 버퍼 Queue(FIFO) = 선입선출 First In First Out
		// Stack = 후입선출(도시락구조 입출구가 하나)  들어간 순서 A -> B -> C  // 나가는 순서 C -> B -> A 
		
		// next() 입력구분자 : 공백또는 엔터
		// nextInt() 입력구분자는 안 읽어온다
		// nextDouble() 첫번째입력구분자는 무시
		// netxBoolean()
//-------------------------------------------------------
		// nextLine() 입력구분자 : 엔터 엔터까지읽어온다
		
		System.out.print("이름 :");
		name = scanner.next(); 			// next = 공백엔터까지 입력받음 문자열 받는 스캐너

		System.out.print("나이 :");
		age = scanner.nextInt();		// 입력받은 int정수를 age에 삽입

		scanner.nextLine(); 			//키보드 버퍼에 남아있는 엔터 가져다 버린다
		
		System.out.print("주소 :");
		addr = scanner.nextLine();	 	// 공백(엔터까지입력받음) 포함해서 입력받을때는 nextLine을받야함

		System.out.print("키 : ");
		hight = scanner.nextDouble();

		System.out.print("결혼유무 : ");
		bMarried = scanner.nextBoolean();
		
		System.out.print("성별 :");
		//문자열은 항상 index가 있다           0    0
		gender = scanner.next().charAt(0); // "남" "녀"

		System.out.println("------[결과보기]-----");
		System.out.printf("이름 : %s\n", name);
		System.out.printf("나이 : %d\n", age);
		System.out.printf("주소 : %s\n", addr);
		System.out.printf("키 : %.1f(cm)\n", hight);
		System.out.printf("나이 : %b\n", bMarried);
		System.out.printf("성별 : %c\n", gender);



		scanner.close();

	}

}
