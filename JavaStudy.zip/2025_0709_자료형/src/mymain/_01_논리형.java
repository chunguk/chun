package mymain;

public class _01_논리형 {

	public static void main(String[] args) {

		// 논리형 자료형 : boolean
		// 상수 : true or false(리터럴)
		// 출력서식 : %b or %B
		// 줄바꾸기 \n == %n
		
		System.out.println(true);
		System.out.printf("%b%n %B\n" , true , true);

		//변수선언
		//자료형 변수명:
		boolean bOk;
		
		bOk = 3 > 2;
		
		System.out.printf("3 > 2 : %b\n", bOk);
		
		bOk = 10 < 1;
		
		System.out.printf("10 < 1 : %b\n",bOk );
		
		
		bOk= "파리"== "파리";
		
		System.out.printf("파리==파리 %b\n", bOk);
	
	     bOk= "파리"== "새";
	
	    System.out.printf("파리==새 %b\n", bOk);
	  
	    //상수
	    final boolean bMan = true;
//	    bMan = false;
	    
	    
	  
	  
	  
	  
	  
}

}
