package mymain;

public class _07_문자열 {

	public static void main(String[] args) {
		//문자열 : String 참조형 변수
		//상수(리터럴) : "ABC" < - 'A' 'B' 'C'
		//출력 서식은  : %s (String)
		
		
		String name = "홍길동";
		
		System.out.printf("%s\n",name);
		
		String strr = "우리나라대한민국";
		// %m.ns : m(전체자릿수) n(출력문자수)
		System.out.printf("%.4s\n",strr); //4개의 문자만 출력한다
		
		
		
	}

}
