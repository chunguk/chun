package mymain;
//import = 위치정보를 알려준다
import java.util.Scanner;

public class _04_문제1 {

	public static void main(String[] args) {
		
		int garo,sero;
		
		
		
		//System.in : 표준입력장치(키보드)
		//System.out: 표준출력장치
		
		//키보드로 부터 입력을 받는다
		//대문자로 클래스(스캐너)만들고 변수 스캐너
		Scanner scanner = new Scanner(System.in);

		
		//스캐너를통해 정수를 입력받아서 garo변수에 넣음
		System.out.print("가로 :");
		garo = scanner.nextInt();
		
		System.out.print("세로 :");
		sero = scanner.nextInt();
		
		System.out.printf("garo: %d\n", garo);
		System.out.printf("sero: %d\n", sero);
		
		

		

		int square = garo * sero;
		System.out.printf("square : %d(cm)\n",square);
		
		//사용완료후에는 반납해라 클로우즈해라~
		scanner.close();
		
		
		
		
	}

}
