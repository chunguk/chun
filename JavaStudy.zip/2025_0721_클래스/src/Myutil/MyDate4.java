package Myutil;

public class MyDate4 { //클래스안에있는변수==필드

	int year;
	int month;
	int day;
	
	public MyDate4() {
		
		super();
		
	}

	public MyDate4(int year, int month, int day) {
		super();
		this.year = year;
		this.month = month;
		this.day = day;
	}

	public MyDate4(int year) {
		super();
		this.year = year;
	}

	public MyDate4(int year, int month) {
		super();
		this.year = year;
		this.month = month;
	}
	
	
	public void diplay() {
		System.out.printf("%02d시%02d분",year,month);
	}
	
	
	
	
	
	
}//End Class
