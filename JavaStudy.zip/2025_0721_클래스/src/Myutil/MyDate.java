package Myutil;

public class MyDate {	//MyDate == 클래스
	// Access Modifier(접근 제한한자)
	
	/*	public 		: 공개모드
	 
	 	protected	보호모드
					: 1)동일 패키지안에 있으면 허용됨
					  2)자식 클래스도 허용됨
					  
		(생략)		: default
					  1)동일패키지허용
					  
		private		: 비공개모드	  
	
	*/
	
	//Member Field / 멤버변수 / 인스턴스변수
	//Encapsulation (캡슐화) or Data Hidding(은닉화)
	//객체지향에서는 변수를 외부로부터 
	//직접접근하지 못하도록 설계
	public		int year;		//퍼블릭은 공개모드
	protected	int	month;		//protected(보호모드)
	private 	int	day;
				int weekday;
				
	
	//멤버 메소드 Setter Method(메소드로 우회해서 접근하게 해줌)
	// 형식 set + Month
	//		setMonth() : Camel표기
			
	public void setMonth(int month ) {	//메소드
		//this = 객체 자신
		this.month = month;
	}
	
	public void setYear(int year) {
		this.year = year;
		
	}
	
	public void setDay(int day) {
		this.day = day;
	}
	
	
	public void setWeekday(int weekday) {
		this.weekday = weekday;
	}

//-----------------[Getter Method]----------------------------------------------	
	// Getter Method 값을 가져오는애들은 겟터메소드
	// 형식 get + month
//			getMonth();	: Camel표기
	public int getMonth() {
		
		return month; //month값을 반환하겠다
	}
	
	public int getYear() {
		return year;
	}
	
	public int getDay() {
		return day;
	}
	
	public int getWeekday() {
		return weekday;
	}
	
	
	//카멜표기법으로 해야된다
	public void display( ) {	//메소드
		
		System.out.printf("%d-%02d-%02d %d요일\n",
							year,month,day,weekday);
		
	}
				
				

}
