package Myutil;

import java.util.Calendar;

public class MyTime2 {

	int hour ;
	int minute ;
	int second ;
	
//	this()생성자	
	
	
	public MyTime2() {  //< - 기본 생성자
		System.out.println("--MyTime2--");

		//				현재시간구하기: 년월일시분초...
		Calendar now	= Calendar.getInstance();
		this.hour		= now.get(Calendar.HOUR);			//12시간제
		this.hour		= now.get(Calendar.HOUR_OF_DAY);	//24시간제
		this.minute		= now.get(Calendar.MINUTE);			//분
		this.second		= now.get(Calendar.SECOND);			//초
		
	}
	
	
	public MyTime2(int hour) {
		//생성자는 초기화 하기위해 존재
		this();		//자기자신의 생성자 MyTime2()을 표현한다
		System.out.println("--MyTime2(hour)--");
//		super();
		
		
		this.hour = hour; 		//시간만 내가 원하는대로 함
		
		Calendar now	= Calendar.getInstance();
		
	}
		public MyTime2(int hour ,int minute) {
			this(hour);
			this.minute = minute;
			System.out.println("--MyTime2--");
		}
		
		
	
	
	
	public void display3() {
	
		String am_pm = (hour<12)? "오전":"오후";
		
		System.out.printf("[%s]%02d시%02d분%02d초\n",
				am_pm,
				hour>12 ? hour-12:hour,
				minute,
				second);
	}
	
	
}
