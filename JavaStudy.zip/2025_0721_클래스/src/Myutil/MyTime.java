package Myutil;

public class MyTime {
	
	int hour;
	int minute;
	int second;
	
	public MyTime() { //초기화

	}

	public MyTime(int hour, int minute, int second) {
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	public MyTime(int hour, int minute) {
		this.hour = hour;
		this.minute = minute;
		second = 1;
	
	}
	public MyTime(int hour) {
		this.hour = hour;
		minute = second =15;
		
		
	}
	
	public void display1() {
		System.out.println(hour + ":" + minute+":"+second );
	}
	public void display2() {
		System.out.println(hour + "시"+ minute +"분"+second+"초");
	}
	public void display3() {
		System.out.println("오후"+hour+":"+minute+":"+second);
	}

	
	
	
	public void setHour(int hour) {
		this.hour = hour;
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}

	public void setSecond(int second) {
		this.second = second;
	}

	//-----------------[Getter Method]----------------------------------------------	
	public int getHour() {
		return hour;
	}
	public int getMinute() {
		return minute;
	}
	public int getSecond() {
		return second;
	}
	
	
	
	public void display() {
		System.out.printf("%02d시%02d분%02d초\n",hour,minute,second);
	};
	
	
	
	public void display6() {
		System.out.println("-----------------------------");
		String am_pm = (hour<12)? "오전":"오후";
		
		System.out.printf("[%s]%02d시%02d분%02d초\n",
				am_pm,
				hour>12 ? hour%12:hour,
				minute,
				second);
	}
	
}//End class
