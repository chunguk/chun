package Myutil;
//@Getter	단축키
//@Setter	단축키
//@Date		단축키
public class MyDate2 {

	//알트 쉽프트 S누르고 제너레이트 게터스앤세터스클릭하면 자동완성해줌
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	private int year;
	private int month;
	private int day;
	
	
	
	
}
