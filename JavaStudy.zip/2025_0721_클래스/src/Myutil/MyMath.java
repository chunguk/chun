package Myutil;

	

public class MyMath { //수학 설계도
	
	//가장 큰수 구하기
	public static int greatest(int ... nr) {
		
		
		int max=Integer.MIN_VALUE;		//가장 작은값부터 시작
	
		for(int n : nr) {	//nr에들어오는 가장작은값
			if(n > max) {
				max = n;
			}
			
		}
		
		return max;
	}
	
	
	
	//가장 작은수 구하기
	public static int least(int ... nr) {
		int min=Integer.MAX_VALUE; 	//가장 큰값부터 시작
		
		for(int n :nr) {
			if(n < min) {
				min = n;
			}
			
		}
		
		return min;
		
		
		
	}


	

}//class
