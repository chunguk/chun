package Myutil;

public class MySingleton {

	//Singleton 구현
	static MySingleton single= null;
	
		
			
		public static MySingleton getinstance() {
			
			//객체가 없으면 생성해라
			if(single==null){
				single = new MySingleton();
			}
			
			return single;
		}
		
		
		
		
		private MySingleton() {
			System.out.println("--MySingleton--");
		}
	
		
		public void display_line() {
			
			
			System.out.println("-----------------");
		}
		
	
}
