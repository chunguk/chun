package Myutil;

public class MyThis {

    public void displayThis() {
        System.out.println("내부에서 this: " + this);
    }
}