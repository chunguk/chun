package Myutil;

public class Save {

	private String name;
	private int 	money;
	
	//정적(공유)변수
	public static double rate;
	
	
	
	public Save() { //기본생성자
		
	}



	public Save(String name, int money) {
		super();
		this.name = name;
		this.money = money;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getMoney() {
		return money;
	}



	public void setMoney(int money) {
		this.money = money;
	}
	
	public void display() {
		System.out.printf("[%s]-[%d]-[%d]\n",
					this.name,money,(int)(money*rate) );
	}
	
	
	
}
