package Myutil;

/*

	생성자(Constructor)Method
	1. 객체 생성시 자동호출되는메소드(단1회)
	2. 객체내에 변수 및 기타 초기화 가능 수행
	3. 형식) 클래스명()
			반환형은없다
	4.생성자는 생략 가능함(생력시JVM에 의해서 기본생성자를 만들어서 처리함)
		생성자가 모두 없을시 만들어서 처리해줌
	5.OverLoad가 가능하다(중복선언)이름은 같은데 인자정보(매게변수)가 다르다
	
			정리 객체생성시 자동호출된다1회 객체네 변수및 기타초기화를해주고 
			형식이 클래스명()이거이고 반환형이 없다
 
 	%생성자는 [void 붙이지마라]
 * */


public class MyDate3 {


	int year;
	int month;
	int day;
	
	//반환형이 없어야 생성자메소드가 된다
	//기본 생성자(default Constructor)
	public  MyDate3() {
		System.out.println("---[MyDate3()]---");
		year = 2025;
		month = day = 1;
	}
	
	//외부로 인자정보 값을 받음
	public MyDate3(int year,int month, int day) {
		this.year = year;		//같은 클래스면 디스붙여라
		this.month = month;
		this.day = day;
		
	}
	
	public MyDate3(int year) {
		this.year = year;
		month = day =1;
		
	}
	
	public MyDate3(int year, int month) {
		this.year = year;
		this.month = month;
		this.day = 1;
	}
	
	
	public void display() {
		System.out.printf("%04d-%02d-%02d\n",year,month,day);
	}
	
	
	
}
