package MyMain;

import Myutil.MyMath;

public class MyMain_VarArgs {	//가변인자
	
	//생략부호 ellipsis = 가변인자 VarArgs
	static void display(int ... nr) {
//							int[] nr = {10};
//							int[] nr = {10,20};
//							int[] nr = {10,20,30};
					
		System.out.print("[");
		for(int n :nr) {
			System.out.printf("%3d", n);
		}
		System.out.println("]");
	}

	
	public static void main(String[] args) {
		//가변인자 : 함수의 전달인자가 정해지지 않았다
		display(10);
		display(10,20);
		display(10,20,30);
		
//		int mm = new Math;
		
		int m = Math.max(10, 5);
		
		//static method호출방법 : 클래스명.메소드명
		int result = MyMath.greatest(1,5,3,2,10);
		int result1 = MyMath.least(1,5,3,2,10);
		
	
		display(result);
		display(result1);
	}

}
