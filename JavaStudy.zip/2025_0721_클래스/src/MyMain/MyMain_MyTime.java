package MyMain;

import Myutil.MyTime;

public class MyMain_MyTime {

	public static void main(String[] args) {
		
//System.out.println("------------------");

//		MyTime time1 = new MyTime();//초기화
		MyTime time1 = new MyTime(18,30,50);
		MyTime time2 = new MyTime(19,50);
		MyTime time3 = new MyTime(20);
		

		time1.display1();
		time2.display2();
		time3.display3();
		time1.display6();

		System.out.println();
		
		System.out.println("-----[Setter]-----");
//		세터 방식
		time1.setHour(18);
		
		time1.setMinute(3);
		
		time1.setSecond(1);
		
		time1.display();
		

			
		int hour   = time1.getHour();
		int minute =time1.getMinute();
		int second =time1.getSecond();
			
			
			
			
		System.out.println("-----[Getter]-----");
		System.out.println(hour);
		System.out.println(minute);
		System.out.println(second);
			
	}//End main

}
