package MyMain;

import Myutil.MyDate;

public class MyMin_MyDate {

	public static void main(String[] args) {
		
		//참조변수 = new 클래스명(); < - 객체
		MyDate in = new MyDate(); //객체 생성
		//			MyDate의 인스턴스(객체)
		
//		in.year = 2025;	//public
		in.setYear(2025);

		//in.month = 3;	//protected
		
		in.setMonth(7);
		
		
		//The field MyDate.day is not visible
		//in.day =31;
		in.setDay(31);
		
		//in.weekday = 2;
		in.setWeekday(2);
		
		
		in.display();
		
//		int year = in.year;
		int year = in.getYear();
		
//		int month = in.month;
		int month = in.getMonth(); //겟먼스값 여기로 줘라
		
		int day = in.getDay();
		
		int weekday = in.getWeekday();
		
		
		
		System.out.println("-----[Getter]-----");
		System.out.println(year);
		System.out.println(month);
		System.out.println(day);
		System.out.println(weekday);
		
		
	}

}
