package MyMain;

import Myutil.Save;

public class MyMain_Save {

	public static void main(String[] args) {
		
		Save[] s_array = {
				new Save("일길홍",1000000),//0
				new Save("이길홍",2000000),//1
				new Save("삼길홍",3000000) //2
		};
		
		//이율설정 => 정적변수 표ㅕ현 : 클래스명.변수명
		Save.rate=0.1;
		
		//The static field Save.rate should be accessed in a static way
//		s_array[0].rate=0.1;
			
		for(int i=0; i < s_array.length; i++) {//i = 0 1 2
			s_array[i].display();
		}
		
		Save.rate =0.3;
		
		System.out.println("--[개선loop방식]--");
		for(Save s : s_array) {
			s.display();
		}
		
		int [] rr = {1,2,3,4,5};
		for(int g : rr) {
			System.out.println(g);
		}
		

	}

}
