package MyMain;

import Myutil.MyDate3;

public class MyMain_MyDate3 {

	public static void main(String[] args) {

	//힙에 만들어진건 다 0으로 초기화됨
		//오버로드생성자는 기본생성자하나는꼭만들자
		MyDate3 d1= new MyDate3();
		MyDate3 d2= new MyDate3(2000, 12, 25);
		MyDate3 d3= new MyDate3(1999);
		MyDate3 d4= new MyDate3(2025,8);
		
		
			d1.display();	
			d2.display();
			d3.display();
			d4.display();
	}

}
