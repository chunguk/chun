package MyMain;

public class MyMain_static_초기화 {
	
	//static 초기화 영역
	static {											//
		
		System.out.println("--0.무슨소리야 내가 먼저 실행된다--");
		System.out.println("--main프로그램 실행전 준비과종 여기서처리--");
		System.out.println("--(DB Driver초기화/이미지 로드)--");
	}

	public static void main(String[] args) {			//메인게임
		
		System.out.println("--1. 내가 제일 먼저 실행된다.--");
		
		
	}

}
