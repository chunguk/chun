package MyMain;

import Myutil.MyThis;

public class MyMainThis {

    public static void main(String[] args) {
    	
        MyThis my = new MyThis(); // MyThis 객체 생성
        MyThis my2 = new MyThis(); // MyThis 객체 생성
        my.displayThis();         // MyThis 안에 정의된 displayThis() 실행
        my2.displayThis();         // MyThis 안에 정의된 displayThis() 실행

        System.out.println("외부에서 my: " + my);
        System.out.println("외부에서 my: " + my);
    }
}
