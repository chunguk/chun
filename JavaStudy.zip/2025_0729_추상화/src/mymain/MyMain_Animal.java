package mymain;

import myutil.Animal;
import myutil.cat;
import myutil.dog;
import myutil.pig;

public class MyMain_Animal {
	
	

	static void ccrryy(Animal [] animal_array){
			for(Animal animal : animal_array) {
				animal.cry();
			}
			for(Animal animal : animal_array) {
				animal.eat();
			}
	}
	public static void main(String[] args) {

		Animal [] animal_array = {	new dog(),
									new cat(),
									new pig()
								 };
		
		ccrryy(animal_array);
	
		
		
		
		
		
		
	}


}
