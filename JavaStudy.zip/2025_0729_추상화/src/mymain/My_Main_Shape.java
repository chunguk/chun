package mymain;


import myutil.MyNenmo;
import myutil.MyTriangle;
import myutil.Triangle;
import myutil.Nenmo;


public class My_Main_Shape {

	   // 도형 출력 메서드 예시
    static void 도형(Triangle t) {
        t.draw();

    }
    static void 도형1(MyNenmo n) {
    	n.draw();
    	
    }
	
	public static void main(String[] args) {
		  MyTriangle t = new MyTriangle();  // ✅ 이렇게 구체 클래스로 생성해야 함
	        도형(t);
	        
	       MyNenmo n = new MyNenmo();
	       도형1(n);
	}

}
