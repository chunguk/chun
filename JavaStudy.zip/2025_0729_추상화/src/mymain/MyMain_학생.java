package mymain;

import myutil.고등학생;
import myutil.대학생;
import myutil.중학생;
import myutil.초등학생;
import myutil.학생;

//컨 쉽 O

public class MyMain_학생 {
	
	
	static void 어머님왈(학생 [] student_array) {
		
				for(학생 student : student_array) {
					
					//Polymorphosm(다형성) : 동일한 명령에 따른 각각의 객체가 다른 행동을 한다.
					student.공부한다();
				}
		
	}

	public static void main(String[] args) {
//		학생 student = new 학생();	//추상클래스는 이런식으로 객체 생성 불가

		
		
		학생 [] student_array = {	new 초등학생(), 
								 	new 중학생(), 
								 	new 고등학생(), 
								 	new 대학생()
								};
		
		
		어머님왈(student_array);
			
	
		
		
		
		
	}//main

}//class
