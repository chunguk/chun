package myutil;

public class cat implements Animal {

	@Override
	public void cry() {
		// TODO Auto-generated method stub
		System.out.println("고양이는 야옹");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("고양이는 츄르");
	}

}
