package myutil;

abstract public class Nenmo extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
		System.out.println("■■■■■■");

	}

}
