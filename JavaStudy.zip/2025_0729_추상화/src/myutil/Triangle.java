package myutil;

public abstract class Triangle extends Shape {

	@Override
		public void draw() {
		// TODO Auto-generated method stub
		System.out.println("▲▲▲▲▲▲");
	}

}
