package myutil;

public class MyNenmo extends Nenmo{

	



}
