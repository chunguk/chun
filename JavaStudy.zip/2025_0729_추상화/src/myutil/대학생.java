package myutil;

public class 대학생 extends 학생 {

	@Override
	public	void 공부한다() {
		System.out.println("대학생 : 3각함수를 공부합니다");

	}

}
