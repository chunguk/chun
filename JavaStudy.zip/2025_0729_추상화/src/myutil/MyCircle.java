package myutil;

public class MyCircle extends Circle{

}
