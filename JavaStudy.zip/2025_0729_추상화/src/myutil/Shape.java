package myutil;

abstract public class Shape {
	  // 추상 메서드 선언
    abstract public void draw();
    
    
    
}


