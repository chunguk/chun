package myutil;


//The type 초등학생 must implement the inherited abstract method 학생.공부한다()
public class 초등학생 extends 학생{

	@Override // 재정의 오버라ㅏㅏ이드
	public	void 공부한다() {
		System.out.println("초등학생 : 구구단을 공부합니다");
		
	}


	
	
}
