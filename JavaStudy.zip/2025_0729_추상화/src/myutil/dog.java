package myutil;

public class dog implements Animal {

	@Override
	public void cry() {
		// TODO Auto-generated method stub
		System.out.println("개는 왈왈 짖습니다");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("개는 잡식입니다");
	}

}
