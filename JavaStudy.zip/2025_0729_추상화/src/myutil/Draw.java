package myutil;

 public class Draw extends Triangle  {

	
	
	
	
}
