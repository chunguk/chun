package myutil;

public class MyTriangle extends Triangle{

}
