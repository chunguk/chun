package myutil;

public abstract class Circle extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("●●●●●●●●●●");

		
	}

}
