package myutil;

public interface Animal {
	
	
    void cry();
    void eat();
}



//부모가 인터페이스일 때	 부모가 클래스일 때
//implements 사용	          extends 사용