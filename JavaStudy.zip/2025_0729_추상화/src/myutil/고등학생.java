package myutil;

public class 고등학생 extends 학생 {

	@Override
	public	void 공부한다() {
		// TODO Auto-generated method stub
		System.out.println("고등학생 : 기하학을 공부합니다");
	}

}
