package myutil;

abstract public class 학생 {	//추상메소드를 포함한 클래스는 추상클래스로 선언필수

	int 학년;
	int 학번;
	
	//추상메소드
	abstract public void 공부한다(); // abstract < - 이게 있으면 {}바디 생략가능
	
		
	
}
