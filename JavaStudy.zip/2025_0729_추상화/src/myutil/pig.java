package myutil;

public class pig implements Animal {

	@Override
 	public void cry() {
		
		System.out.println("돼지는 꿀꿀");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("돼지는 사람도 먹습니다");
	}

}
