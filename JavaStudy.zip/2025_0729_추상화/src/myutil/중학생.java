package myutil;

public class 중학생 extends 학생 {

	@Override
	public void 공부한다() {
		System.out.println("중학생 : 2차방정식을 공부합니다");

	}

}
