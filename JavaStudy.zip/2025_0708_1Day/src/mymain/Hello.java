package mymain;

public class Hello {
// 세이브가 되는 순간 컴파일 완료됨

//  단축키

//  1라인 주석     : Ctrl + /(toggle)
//  여러라인 주석  : Ctrl + Shift + / (설정)
//  주석 해제      : Ctrl + Shift + \ (해제)

//  화면 확대 / 축소: Ctrl+Shift + (+)
//  화면 정렬      : Ctrl + Shift + F
//	import 정렬    : Ctrl + Shift + O

//	복사 		   : Ctrl + Alt + win + 화살표

	public static void main(String[] args) {

//       System : 클래스명
//        out : 객체명
//        println : 메소드명(함수명)  print  + line next (줄바꾸기
//        print   : 출력만하는데 출바꿈 없음		
//        printf  : 출력서식대로 출력해라		

//        CUI (Console User Interface)
//        TUI (Text User Interface)

//        Console = 입출력 장치

//		  syso + Ctrl + space 
//		  syse + Ctrl + space		

		System.out.println("안녕하세요" + 1);
		System.out.print("안녕하세요" + 2);
		System.out.println("안녕하세요" + 3);

		System.err.println("에러내용출력");
		System.err.println("에러내용출력1");

		// printf사용
		String name = "홍길동"; // %s < String (문자열)
		int age = 30; // %d Decimal 10진수
		double ki = 183.5; // %f <- Float(실수) %.1f .1이 소숫점 표시할 갯수

		// 1 2 3
		System.out.printf("이름 :%s\n나이 : %d(세)\n신장 : %.1f(cm)\n",
//								  1           2              3				
				name, age, ki);

		// write("문자)
		System.out.println("65" + "a");
		
		
		int i =65;
		
		System.out.println((char)i+5);

	}

}
