package mymain;

public class MyProfile {

	public static void main(String[] args) {
		String name = "황춘국";
		int age = 91;
		double ki = 183.1;
		String hobby = "농구";
		String food = "떡볶이";
		String adress= "신림";
		
		//┌     ─    ┐   ┘│ └
		System.out.println("┌───────────┐");
		System.out.println("│                      │");
		System.out.println("│     My Proflie       │");
		System.out.println("│                      │");
		System.out.printf("│이름은 : %s       │\n│나이는 :%d년생        │\n│신장은 :%.1f         │\n│좋아하는음식은:%s │\n│사는곳은:%s         │\n│취미는 : %s         │\n",name,age,ki,food,adress,hobby);
		System.out.println("│                      │");
		System.out.println("│                      │");
		System.out.println("│                      │");
		System.out.println("│                      │");
		System.out.println("└───────────┘");

		
	}

}
