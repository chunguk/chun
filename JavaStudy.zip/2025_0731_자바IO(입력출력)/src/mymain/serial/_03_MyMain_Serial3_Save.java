package mymain.serial;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import vo.PersonVo;

public class _03_MyMain_Serial3_Save {

	
	//Serializable 갖고있으면 직렬화가 가능하다
	public static void main(String[] args) throws Exception {
		
		
		PersonVo p2 = new PersonVo("김영환" , 32, "경기도 부천시 영환로");

		PersonVo []  p_array = {
				new PersonVo("김영환" , 32, "경기도 부천시 영환로"),
				new PersonVo("곽호성" , 34, "서울시 관악구 호성로"),
				new PersonVo("최  웅" , 33, "서울시 강서구 최웅로"),
				new PersonVo("이대한" , 36, "서울시 관악구 대한로"),
				new PersonVo("이민국" , 36, "서울시 관악구 민국로"),
			};
		
		
		//쓰기파일열기
		OutputStream os = new FileOutputStream("Person_array.dat");
		
		
		
		//객체를 저장하는 Stream : 직렬화 처리 데이터는 binary data
		ObjectOutputStream oos = new ObjectOutputStream(os);
		
		//객체저장(직렬화 : 객체정보를 분해해서 저장처리)
		oos.writeObject(p_array);
		
		
		//파일 닫기
		oos.close();
		os.close();
		
		
		
	}

}
