package mymain.serial;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

import vo.PersonVo;

public class _04_MyMain_Serial4_Open {

	public static void main(String[] args) throws Exception {
		
		InputStream is = new FileInputStream("person_array.dat");
		
		ObjectInputStream ois = new ObjectInputStream(is);
		
		
		//읽어오기
		PersonVo [] p_array = (PersonVo[]) ois.readObject();
		
			for(int i=0; i < p_array.length; i++) {
				System.out.printf("[%d] %s\n",i,p_array[i]);
			}
			
			System.out.println("------------------[향상된for문]---------------------");
			System.out.println();
			for(PersonVo p : p_array) {
				System.out.println(p);
			}
				
		ois.close();
		is.close();
	}

}
