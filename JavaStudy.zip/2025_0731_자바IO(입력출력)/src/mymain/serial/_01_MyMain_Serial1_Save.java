package mymain.serial;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import vo.PersonVo;

public class _01_MyMain_Serial1_Save {

	
	//Serializable 갖고있으면 직렬화가 가능하다
	public static void main(String[] args) throws Exception {
		
		
		PersonVo p1 = new PersonVo("김영환" , 32, "경기도 부천시 영환로");

		
		//쓰기파일열기
		OutputStream os = new FileOutputStream("Person.dat");
		
		
		
		//객체를 저장하는 Stream : 직렬화 처리 데이터는 binary data
		ObjectOutputStream oos = new ObjectOutputStream(os);
		
		//객체저장(직렬화 : 객체정보를 분해해서 저장처리)
		oos.writeObject(p1);
		
		
		//파일 닫기
		oos.close();
		os.close();
		
		
		
	}

}
