package mymain.serial;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import vo.PersonVo;

import java.io.InputStream;

public class _02_MyMain_Serial2_Open {

	public static void main(String[] args) throws Exception {
		
		InputStream is = new FileInputStream("person.dat");
		
		
		ObjectInputStream ois = new ObjectInputStream(is);
		
		
		//객체 읽어오기 다운캐스팅으로 형변환
		PersonVo p =  (PersonVo) ois.readObject();
		
		System.out.println(p);
		
		
		//닫기
		ois.close();
		is.close();
	}

}
