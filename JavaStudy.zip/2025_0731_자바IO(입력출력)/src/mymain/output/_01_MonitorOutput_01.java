package mymain.output;

import java.io.OutputStream;

public class _01_MonitorOutput_01 {

	public static void main(String[] args) throws Exception {
		
		//표준출력장치 : System.out <- PrintStream <- OutputStream
		OutputStream os = System.out;
		
		//출력버퍼에 기록을 한다
		os.write(65);
		
		os.write('B');

		os.write('1');
		
		String  msg = "안녕하세요";
		//String -> byte[]
		
		byte [] byte_msg = msg.getBytes();
			
		os.write(byte_msg);
		
		int n = 123;
		//모든값 ->String생성
		//방법1) String valueOF();
		//방법2) n+1 + " ";
		
		System.out.println();
		
		String strN = String.valueOf(n);	//123 - > "123"
		os.write(strN.getBytes());
		
		os.write('\n');
		
		double tall = 183.4;
		String strNtall = String.valueOf(tall);
		os.write(strNtall.getBytes());
		
		
		//출력 버퍼를 비우기 -> 버퍼내용이 화면으로전송
		os.flush();
		
		
		
	}//main


}
