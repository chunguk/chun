package mymain.output;

import java.io.FileOutputStream;
import java.io.OutputStream;

public class _02_MonitorOutpit_03 {

	public static void main(String[] args) throws Exception {
		//출력 방법은 01이랑 똑같은데 파일에 저장됨
		OutputStream os = new FileOutputStream("data.txt");

		os.write(6);
		
		os.write('n');

		os.write('7');
		
		os.write('\n');
		String  msg = "안녕하세요";
		//String -> byte[]
		int n = 123;
		String strN = String.valueOf(n);	//123 - > "123"
		os.write(strN.getBytes());
		
		os.write('\n');
		
		
		byte [] byte_msg = msg.getBytes();
			
		os.write(byte_msg);		
		
		os.write('\n');
		
		double tall = 183.4;
		String strNtall = String.valueOf(tall);
		os.write(strNtall.getBytes());		

		
		//파일은 항상 닫아라 스캐너도 닫아라
		os.close();
	}

	
}
