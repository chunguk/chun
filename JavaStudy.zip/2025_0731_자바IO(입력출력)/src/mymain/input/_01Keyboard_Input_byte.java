package mymain.input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class _01Keyboard_Input_byte {

	public static void main(String[] args) throws IOException {


		//표준입출력장치
		//입력 : System.in
		//출력 : System.out
		
		InputStream is =System.in;
		InputStreamReader isr = new InputStreamReader(is,"UTF-8");      // 문자 스트림

		BufferedReader br = new BufferedReader(isr);

		System.out.println("데이터를 입력해보세요(종료:Crtl+Z)");
		
		while(true){
//			
//			//키보드 버퍼로부터 byte씩 읽어온다
//			int ch = is.read();
//			
//			
//			if(ch==-1)break; //Ctrl+z 브레이크
//			
//			System.out.printf("%c",ch);
			
			String data = br.readLine();//줄단위로 읽는다(엔터를 구분자: 엔터는 버린다)
			if(data == null)break; //읽어올게없으면 멈춰라
			
			System.out.println(data);
			
			
			
			
		}//end whild

		System.out.println("---END---");
		
	}

}
