package mymain.input;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;

public class _02File_Ouput_2 {

	public static void main(String[] args) throws Exception   {
		
		
	
		OutputStream os = new FileOutputStream("data2.txt");

		PrintStream out = new PrintStream(os);
		
		String name 	= "김영환";
		int age 		= 32;
		double ki		= 193.5;
		
		out.printf("이름 : %s\n",name);
		out.printf("나이 : %d\n",age);
		out.printf("키   : %.1f",ki);
		
		System.out.printf("이름 : %s\n",name);
		System.out.printf("나이 : %d(세)\n",age);
		System.out.printf("키   : %.1f(cm)\n",ki);
		
		
		//Close : 열린 역순으로 닫아야함
		out.close(); // 2
		os.close();  // 1
		
		
		
	}//main

}