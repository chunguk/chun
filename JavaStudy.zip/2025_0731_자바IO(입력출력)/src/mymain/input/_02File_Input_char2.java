package mymain.input;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class _02File_Input_char2 {

	public static void main(String[] args) throws Exception   {
		
		
		//1.File Open(파일열기)
		InputStream is = new FileInputStream("src/mymain/input/_02File_Input_char2.java");
		
		//2.Filter
		InputStreamReader isr = new InputStreamReader(is);
		
		BufferedReader br = new BufferedReader(isr);

		while(true) {
			
//			int ch = isr.read();
//			
//			if(ch==-1)break;
//			
//			System.out.printf("%c",ch);
			
			String data = br.readLine();//줄단위로 읽는다(엔터를 구분자: 엔터는 버린다)
			if(data == null)break; //읽어올게없으면 멈춰라
			
			System.out.println(data);
			
		}
		
		
		
		//Close : 열린 역순으로 닫아야함
		isr.close();
		is.close();
		
		
		
	}//main

}