package mymain.input;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class _03_Network_01char2 {

	public static void main(String[] args) throws Exception {
		
		String host = "https://www.naver.com/";
		
		//Uniform Resource Locator(웹의 컨텐츠의 위치를 지정하는 주소형식)
		URL url = new URL(host);
		
		InputStream is = url.openStream();                      // 바이트 스트림
		InputStreamReader isr = new InputStreamReader(is,"UTF-8");      // 문자 스트림
		
		BufferedReader br = new BufferedReader(isr);
		
		
		
		while(true) {
			
//			int ch = isr.read();
//			
//			if(ch==-1)break;
//			
//			System.out.printf("%c",ch);
			
			String data = br.readLine();//줄단위로 읽는다(엔터를 구분자: 엔터는 버린다)
			if(data == null)break; //읽어올게없으면 멈춰라
			
			System.out.println(data);
		
//			Thread.sleep(1000);
		}
		
	}

//	private static InputStreamReader InputStreamReader(InputStream is, String string) {
//		// TODO Auto-generated method stub
//		return null;
//	}



}
