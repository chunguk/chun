package mymain.input;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class _01Keyboard_Input_char {

	public static void main(String[] args) throws IOException {


		//표준입출력장치
		//입력 : System.in
		//출력 : System.out
		
		InputStream is =System.in;
		
		//Fillter 씌우기 : byte stream -> char stream
		InputStreamReader isr = new InputStreamReader(is); 
		
		System.out.println("데이터를 입력해보세요(종료:Crtl+Z)");
		
		while(true){
			
			
			int ch = isr.read();	//키보드 버퍼로부터 char씩 읽어온다
			
			if(ch==-1)break; 		//Ctrl+z 브레이크
			
			System.out.printf("%c",ch);
			
			
		}//end whild

		System.out.println("---END---");
		
	}

}
