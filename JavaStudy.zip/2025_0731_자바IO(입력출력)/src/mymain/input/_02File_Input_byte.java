package mymain.input;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class _02File_Input_byte {

	public static void main(String[] args) throws Exception   {
		
		
		//File Open
		InputStream is = new FileInputStream("D:\\Work\\JavaStudy\\2025_0731_자바IO(입력출력)\\bin\\mymain\\input/_02File_Input_byte.class");
		
		while(true) {
			
			int ch = is.read();
			
			if(ch==-1)break;
			
			System.out.printf("%c",ch);
			
			
		}
		
		
		
		//Close
		is.close();
		
		
		
	}//main

}