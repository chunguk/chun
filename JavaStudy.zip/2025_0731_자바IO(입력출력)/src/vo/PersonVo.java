package vo;

import java.io.Serializable;

// VO(Value Object)
//  : 값을 저장관리하는 객체

// cf)DTO(Data Transfer Object):전달객체(Rest API)

//        interface를 쓴이유  implements Serializable    직렬화가 가능한 객체라고 알려준다

public class PersonVo implements Serializable{	//객체
	//Serializable 갖고있으면 직렬화가 가능하다

	String 	name;
	int 	age;
	String 	addr;
	
	
	
	public PersonVo() {		//default
		
	}
	
	
	//생성자는 디폴트생성자 만들어야됨
	public PersonVo(String name, int age, String addr) {
		super();
		this.name = name;
		this.age = age;
		this.addr = addr;
	}
	
	
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("[%s - %d - %s - : 無]\n",name,age,addr);
		
	}


	//get set
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	
}
