package myutil;

public class Eagle extends Bird {

	@Override
	public void fly() {
		System.out.println("독수리가 높이난다");
		super.fly();
	}

	@Override
	public void eat() {
		System.out.println("독수리가 먹이를 먹는다");
		super.eat();
	}

	@Override
	public void size() {
		System.out.println("독수리의 크기는 큽니다");
		super.size();
	}

	
	
}
