package myutil;

public interface Channel {

	int MIN  = 	0;
	int MAX  =	999;
	
	void ChannelUP();
	void ChannelDown();
	void setChannel(int ch);
	void volumeUp();
	void volumeDown();
	
	
}
