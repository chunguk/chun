package myutil;

public interface Volume {

	
	int MIN = 0;
	int MAX = 100;
	
	void volumeUp();
	void volumeDown();
	void volumeZero();
	
	
}
