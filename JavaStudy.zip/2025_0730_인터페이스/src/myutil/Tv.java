package myutil;

public class Tv implements RemoteCon {
		int volume  = 10;
		int channel = 0;
			
		boolean bOnOff      = false;//켜짐 꺼짐
		boolean bSoundOff   = false; //음소거상태냐?
		
		
	@Override
	public void volumeUp() {
		volume++;
		if(volume > Volume.MAX) {
			volume = Volume.MAX;
		}
		display();

	}

	@Override
	public void volumeDown() {
		volume--;
		if(volume < Volume.MIN) {
			volume = Volume.MIN;
		}

	}

	@Override
	public void volumeZero() {
		bSoundOff = !bSoundOff;	//토글
		
		display(); 	//출력

	}

	@Override
	public void ChannelUP() {
		channel++;
		if(channel > Channel.MAX) {
			channel = Channel.MIN;
		}
		display();

	}

	@Override
	public void ChannelDown() {
		channel--;
		if(channel < Channel.MIN) {
			channel = Channel.MAX;
		}
		display();
	}

	@Override
	public void setChannel(int ch) {
		if(ch >=Channel.MIN && ch <=Channel.MAX) {
				this.channel = ch;
		}else {
			System.out.println("유효하지 않은 채널 번호입니다.");
			   }
		
			display();
	}

	@Override
	public void onOff() {
		//Toggle기능 : True <-> false
		bOnOff = !bOnOff; //토글처리
		
		display();
		
	}
	
	private void display() {
		
		System.out.println("-------[Tv]-------");
		if(bOnOff==false) {
			
			System.out.println("상태 : 꺼짐");
			return;
		}
		
		//켜졌을때 상태
		
		System.out.printf("채널 : %d\n",channel);
		
		if(bSoundOff)
			System.out.println("소리 : 음소거");
		else
			System.out.printf("소리 : %d\n",volume);
		
		
		
		
	}
	
	

}
