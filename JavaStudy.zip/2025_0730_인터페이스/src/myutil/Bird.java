package myutil;

public class Bird {


	
	
	public void fly() {
		
	}
	public void eat() {
		
	}
	public void size() {
		
	}
	
}
