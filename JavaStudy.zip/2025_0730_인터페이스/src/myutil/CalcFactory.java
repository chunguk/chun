package myutil;

public class CalcFactory {

	static CalcFactory single = null;
	
	public static CalcFactory getInstance() {
		
		if(single == null)
				single = new CalcFactory();	
		
		return single;
	}
	
	
	//외부에서 생성 못하도록 설정
	private CalcFactory() { //생성자
		
	}
	
	public BaseCalc getCalc() {			//칼크객체 필요하니까 하나줘
		 
		
		return new BaseCalcImpl();		//어 칼크객체 하나 만들어줄게
		
		
	}
	
}
