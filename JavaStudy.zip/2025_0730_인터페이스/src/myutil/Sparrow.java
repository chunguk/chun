package myutil;

public class Sparrow extends Bird {

	@Override
	public void fly() {
		System.out.println("참새가 하늘는 난다");
		
	}

	@Override
	public void eat() {
		System.out.println("참새가 모이를 먹는다");
		
	}
	@Override
	public void size() {
		System.out.println("참새는 크기가 작다");
	}
	
}
