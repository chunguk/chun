package myutil;


//다중상속
public interface RemoteCon extends Volume,Channel{

	//티비 온오프
	void onOff();

	void volumeUp();
	
	
	
}
