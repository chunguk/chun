package myutil;

public class Parrot extends Bird {

	@Override
	public void fly() {
		System.out.println("앵무새는 잘납니다");
		super.fly();
	}

	@Override
	public void eat() {
		System.out.println("앵무새는 모이를 먹습니다");
		super.eat();
	}

	@Override
	public void size() {
		System.out.println("앵무새는 참새보단 크고 독수리보단 작습니다");
		super.size();
	}

	
}
