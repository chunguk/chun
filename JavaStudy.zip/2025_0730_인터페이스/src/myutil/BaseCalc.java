package myutil;

public interface BaseCalc {

	//상수/추상메소드/default메소드
	//interface내에 모든항목의 접근제한자는 public이다
	//인터페이스 안에서는 다 상수니까 편하게 써도된다
	public static final double PI2= 3.14;
	double PI = 3.14;
	
	//추상메소드 = 바디가 없다
	abstract public int plus(int a,int b);
					 int minus(int a,int b);
	
	
	//JDK 버전 8.0 이상부터 지원				 
	//optional 메소드 (필요에 따라서 override(재정의)해라)
	default int hap(int n) {return 0;}				 
					 

	
	
}
