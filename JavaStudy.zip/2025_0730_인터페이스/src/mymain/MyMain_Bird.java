package mymain;

import myutil.Bird;
import myutil.Eagle;
import myutil.Parrot;
import myutil.Sparrow;

public class MyMain_Bird {
	public static void main(String[] args) {
		Bird [] birds = {
				new Eagle(),
				new Sparrow(),
				new Parrot()
		};
	
		
		
		for(int i =0; i< birds.length; i++) {
				birds[i].fly();
				birds[i].eat();
				birds[i].size();
		}
	}
}

