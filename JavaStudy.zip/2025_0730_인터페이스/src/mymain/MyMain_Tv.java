package mymain;

import myutil.Channel;
import myutil.RemoteCon;
import myutil.Tv;
import myutil.Volume;

public class MyMain_Tv {

	public static void main(String[] args) {
		
		//인터페이스		=     클래스
		RemoteCon remoteCon = new Tv();
		
		remoteCon.onOff(); //꺼짐
		remoteCon.onOff(); //켜짐
		
		remoteCon.onOff();//꺼짐
		
		remoteCon.volumeZero();//음소거 설정
		remoteCon.volumeZero();//음소거 해제
		
		//Up-casting
		Volume volume = remoteCon;
		
		
		
		for(int i=0; i<101; i++) {	//볼륨다운
			remoteCon.volumeDown();
		}
		
		for(int i=0; i<91; i++) {	//볼륨업
			volume.volumeUp();
		}
		
		
		for(int i=0; i<Channel.MAX; i++) {
				if(i==Channel.MAX+1)break;
			remoteCon.ChannelUP();
		}
		
		for(int i=0; i>Channel.MIN; i--) {
			if(i==Channel.MIN-1)break;
			remoteCon.ChannelDown();
		}
		
		remoteCon.setChannel(777);
		
		
		
		
	}//main
	
}
